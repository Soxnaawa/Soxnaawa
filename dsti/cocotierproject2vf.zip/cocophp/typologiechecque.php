<!DOCTYPE html>
<html>
<head>
    <title>Typologie Checque</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <!-- Formulaire pour déclarer les réclamations de chèques -->
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
    <legend><h2>Typologie cheque </h2></legend>
        <fieldset>
            <legend><h2>Typologie</h2></legend>
            <label for="debutperiode">Date de début</label><br>
            <input type="date" id="debutperiode" name="debutperiode" required><br>
            <label for="finperiode">Date de fin</label><br>
            <input type="date" id="finperiode" name="finperiode" required><br>
        </fieldset>
        <fieldset>
            <legend><h3>Détails des Typologies de Cheque</h3></legend>
            <div id="details">
                <!-- Les champs pour les détails des acquisitions de cheques seront générés ici par JavaScript -->
            </div>
            <button type="button" onclick="ajouterTypologie()">Ajouter Typologie Cheque</button>
           

        </fieldset>
        <input type="submit" value="Soumettre">
    </form>

    <script>
    var numTypologie = 1; // Initialisation du compteur de Typologie

    function ajouterTypologie() {
        var detailsDiv = document.getElementById('details');

        var fieldset = document.createElement('fieldset');
        var legend = document.createElement('legend');
        legend.textContent = 'Typologie De Cheque ' + numTypologie;
        fieldset.appendChild(legend);

        // Génération automatique du code du type de cheque
        var typechequecode = 'TCHEQUE_' + numTypologie;

        var labelTypechequecode = document.createElement('label');
        labelTypechequecode.textContent = 'Code du Type de Cheque';
        var inputTypechequecode = document.createElement('input');
        inputTypechequecode.type = 'text';
        inputTypechequecode.name = 'typechequecode[]';
        inputTypechequecode.value = typechequecode;
        inputTypechequecode.readOnly = false; // Pour empêcher la modification
        inputTypechequecode.required = true;

        var labelDescription = document.createElement('label');
        labelDescription.textContent = 'Description';
        var inputDescription = document.createElement('input');
        inputDescription.type = 'text';
        inputDescription.name = 'description[]';
        inputDescription.required = true;

        var labelNombrecheque = document.createElement('label');
        labelNombrecheque.textContent = 'Nombre cheque';
        var inputNombrecheque = document.createElement('input');
        inputNombrecheque.type = 'number';
        inputNombrecheque.name = 'nombrecheque[]';
        inputNombrecheque.required = true;

        fieldset.appendChild(labelTypechequecode);
        fieldset.appendChild(inputTypechequecode);
        fieldset.appendChild(document.createElement('br'));

        fieldset.appendChild(labelDescription);
        fieldset.appendChild(inputDescription);
        fieldset.appendChild(document.createElement('br'));

        fieldset.appendChild(labelNombrecheque);
        fieldset.appendChild(inputNombrecheque);
        fieldset.appendChild(document.createElement('br'));

        // Ajouter le bouton de retour
        var button = document.createElement('button');
        button.type = 'button';
        button.textContent = 'Supprimer';
        button.onclick = function() {
            detailsDiv.removeChild(fieldset);
        };

        fieldset.appendChild(button);
        detailsDiv.appendChild(fieldset);

        numTypologie++; // Incrémentation du compteur de Typologie pour la prochaine fois
    }
</script>


<?php
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname = "users";
// Connexion à la base de données
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}


    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Récupération des données soumises
        $debutperiode = $_POST["debutperiode"];
        $finperiode = $_POST["finperiode"];
        $typechequecode = $_POST["typechequecode"];
        $description = $_POST["description"];
        $nombrecheque = $_POST["nombrecheque"];

        $totalNombre = array_sum($nombrecheque);
        
        // Afficher les données soumises
        echo "<div id='donneesSoumises'>";
        echo "<h2>Données Soumises</h2>";
        echo "<p><strong>Date de début :</strong> " . htmlspecialchars($debutperiode) . "</p>";
        echo "<p><strong>Date de fin :</strong> " . htmlspecialchars($finperiode) . "</p>";
        echo "<p><strong>total Nombre cheque : </strong>" . htmlspecialchars($totalNombre) . "</p>";
        echo "<h3>Détails des typologies de Paiement</h3>";

       
      
        $stmt = $conn->prepare("INSERT INTO typologies_cheque (debutperiode, finperiode, typechequecode, description, nombrecheque) VALUES (?, ?, ?, ?, ?)");
        for ($i = 0; $i < count($typechequecode); $i++) {
            echo "<p><strong>Code du Type de cheque :</strong> " . htmlspecialchars($typechequecode[$i]) . "</p>";
            echo "<p><strong>Description :</strong> " . htmlspecialchars($description[$i]) . "</p>";
            echo "<p><strong>Nombre cheque :</strong> " . htmlspecialchars($nombrecheque[$i]) . "</p>";
        }
        echo "</div>";
        for ($i = 0; $i < count($typechequecode); $i++) {
            $stmt->bind_param("ssssi", $debutperiode, $finperiode, $typechequecode[$i], $description[$i], $nombrecheque[$i]);
    
            // Exécution de la requête
            if (!$stmt->execute()) {
                echo "Erreur lors de l'insertion : " . $stmt->error;
            }
        }
    
        // Fermeture de la requête
        $stmt->close();

        // Générer le fichier XML
        $xml = new DOMDocument('1.0', 'UTF-8');
        $xml->formatOutput = true;

        // Élément racine <typologiecheque>
        $typologiecheque = $xml->createElement('typologiecheque');
        $xml->appendChild($typologiecheque);

        // Élément <typologie>
        $typologie = $xml->createElement('typologie');
        $typologiecheque->appendChild($typologie);

        // Ajouter les éléments <debutperiode> et <finperiode>
        $typologie->appendChild($xml->createElement('debutperiode', $debutperiode));
        $typologie->appendChild($xml->createElement('finperiode', $finperiode));

        // Calculer le total du nombre de cheques et de la valeur CFA
        
       

        // Ajouter les éléments <totalnombre> et <totalvaleurcfa>
        $typologie->appendChild($xml->createElement('totalnombre', $totalNombre));
        

        // Élément <details>
        $details = $xml->createElement('details');
        $typologiecheque->appendChild($details);

        // Ajouter les détails des typologies de paiement
        for ($i = 0; $i < count($typechequecode); $i++) {
            $typecheque = $xml->createElement('typecheque');
            $typecheque->setAttribute('code', $typechequecode[$i]);

            $descriptionElem = $xml->createElement('description');
            $descriptionElem->appendChild($xml->createCDATASection($description[$i]));
            $typecheque->appendChild($descriptionElem);

            $nbchequeElem = $xml->createElement('nbcheque', $nombrecheque[$i]);
            $typecheque->appendChild($nbchequeElem);

            // Vérifier si la valeur CFA est définie pour l'élément
            $details->appendChild($typecheque);
        }

        // Créer la période de référence
       // $refperiode = date('Ym', strtotime($debutperiode)) . '-' . date('Ym', strtotime($finperiode));

        // Générer le nom du fichier en utilisant la cheque spécifiée
       // $xml_filename = "EME_CODEETABLISSEMENT_{$refperiode}_S_TYPOLOGIECHEQUE_1_XML.XML";
       // $xml->save($xml_filename);


       $codeEmetteur = "CODEETABLISSEMENT"; // Remplacez par la valeur appropriée
   $refPeriode = date("d_m_Y");
   $frequence = "S"; // Exemple, remplacez par la valeur appropriée
   $codeBranche = "UTILISATIONCHECQUE"; // Remplacez par la valeur appropriée

   // Déterminer la version du fichier
   $version = 1;
   $baseFilename = "EME_{$codeEmetteur}_{$refPeriode}_{$frequence}_{$codeBranche}_";
   $directory = __DIR__; // Répertoire actuel
   $files = glob($directory . "/" . $baseFilename . "*.xml");

   if ($files) {
       // Extraire les numéros de version des fichiers existants et déterminer le prochain numéro de version
       $maxVersion = 0;
       foreach ($files as $file) {
           if (preg_match('/_(\d+)_XML\.XML$/', $file, $matches)) {
               $fileVersion = (int)$matches[1];
               if ($fileVersion > $maxVersion) {
                   $maxVersion = $fileVersion;
               }
           }
       }
       $version = $maxVersion + 1;
   }

   $xml_filename = "{$baseFilename}{$version}_XML.XML";
   $xml->save($xml_filename);
        

    
         // Exécution de la requête pour chaque incident

         // Afficher le message de succès avec un lien vers le fichier XML
         echo "<div style='font-family: Arial, sans-serif; text-align: center; margin-top: 10px; padding: 30px;'>";
         echo "<h2 style='color: #008a50;'>Les informations ont été enregistrées.</h2>";
         echo "<a href='$xml_filename'>Télécharger le fichier XML</a><br>";
         echo "</div>";
    }
    $conn->close();
    ?>
</body>
</html>


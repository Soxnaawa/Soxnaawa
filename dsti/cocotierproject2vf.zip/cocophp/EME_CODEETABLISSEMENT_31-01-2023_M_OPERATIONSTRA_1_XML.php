<!DOCTYPE html>
<html>
<head>
    <title>Operation STRA</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <fieldset>
        <legend><h2>Operation STRA</h2></legend>
        <label for="debutperiode">Début de période:</label><br>
        <input type="date" id="debutperiode" name="debutperiode" required><br>
        <label for="finperiode">Fin de période:</label><br>
        <input type="date" id="finperiode" name="finperiode" required><br>
        <label for="nb_transaction_emission">Nombre de transactions émission:</label><br>
        <input type="number" id="nb_transaction_emission" name="nb_transaction_emission" required><br>
        <label for="valeur_transaction_emission">Valeur de transactions émission:</label><br>
        <input type="number" id="valeur_transaction_emission" name="valeur_transaction_emission" required><br>
        <label for="nb_transaction_reception">Nombre de transactions réception:</label><br>
        <input type="number" id="nb_transaction_reception" name="nb_transaction_reception" required><br>
        <label for="valeur_transaction_reception">Valeur de transactions réception:</label><br>
        <input type="number" id="valeur_transaction_reception" name="valeur_transaction_reception" required><br>
    </fieldset>

    <div id="details"></div>

    <button type="button" onclick="ajouterService()">Ajouter Service</button>
   
    <input type="submit" value="Soumettre">
</form>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connexion à la base de données
    $servername = "localhost"; // À adapter selon votre configuration
    $username = "root"; // À adapter selon votre configuration
    $password = ""; // À adapter selon votre configuration
    $dbname = "users"; // À adapter selon votre configuration

    // Création de la connexion
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérification de la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Préparation de la requête d'insertion
    $stmt = $conn->prepare("INSERT INTO operationstra (debutperiode, finperiode, nb_transaction_emission, valeur_transaction_emission, nb_transaction_reception, valeur_transaction_reception, service, pays, motif, detail_nb_transaction_emission, detail_valeur_transaction_emission, detail_nb_transaction_reception, detail_valeur_transaction_reception) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $debutperiode = $_POST['debutperiode'];
    $finperiode = $_POST['finperiode'];
    $nb_transaction_emission = $_POST['nb_transaction_emission'];
    $valeur_transaction_emission = $_POST['valeur_transaction_emission'];
    $nb_transaction_reception = $_POST['nb_transaction_reception'];
    $valeur_transaction_reception = $_POST['valeur_transaction_reception'];

    echo "<div id='donneesSoumises'>";
    echo "<h2>Données soumises :</h2>";
    echo "<fieldset>";
    //echo "<legend>Informations soumises</legend>";
    echo "<p>Début de période : " . $debutperiode . "</p>";
    echo "<p>Fin de période : " . $finperiode . "</p>";
    echo "<p>Nombre de transactions émission : " . $nb_transaction_emission . "</p>";
    echo "<p>Valeur de transactions émission : " . $valeur_transaction_emission . "</p>";
    echo "<p>Nombre de transactions réception : " . $nb_transaction_reception . "</p>";
    echo "<p>Valeur de transactions réception : " . $valeur_transaction_reception . "</p>";

    // Création de l'objet XML
    $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><operationstra/>');
    $declaration = $xml->addChild('declaration');
    $declaration->addChild('debutperiode', $debutperiode);
    $declaration->addChild('finperiode', $finperiode);
    $declaration->addChild('nb_transaction_emission', $nb_transaction_emission);
    $declaration->addChild('valeur_transaction_emission', $valeur_transaction_emission);
    $declaration->addChild('nb_transaction_reception', $nb_transaction_reception);
    $declaration->addChild('valeur_transaction_reception', $valeur_transaction_reception);

    $details = $xml->addChild('details');

    if (isset($_POST['service'])) {
        echo "<h3>Details :</h3>";
        echo "<ul>";
        foreach ($_POST['service'] as $key => $value) {
            $service = $_POST['service'][$key];
            $pays = $_POST['pays'][$key];
            $motif = $_POST['motif'][$key];
            $detail_nb_transaction_emission = $_POST['detail_nb_transaction_emission'][$key];
            $detail_valeur_transaction_emission = $_POST['detail_valeur_transaction_emission'][$key];
            $detail_nb_transaction_reception = $_POST['detail_nb_transaction_reception'][$key];
            $detail_valeur_transaction_reception = $_POST['detail_valeur_transaction_reception'][$key];

            echo "<li>Data " . ($key + 1) . "</li>";
            echo "<ul>";
            echo "<li>Service : " . $service . "</li>";
            echo "<li>Pays : " . $pays . "</li>";
            echo "<li>Motif : " . $motif . "</li>";
            echo "<li>Nombre de transactions émission : " . $detail_nb_transaction_emission . "</li>";
            echo "<li>Valeur de transactions émission : " . $detail_valeur_transaction_emission . "</li>";
            echo "<li>Nombre de transactions réception : " . $detail_nb_transaction_reception . "</li>";
            echo "<li>Valeur de transactions réception : " . $detail_valeur_transaction_reception . "</li>";
            echo "</ul>";

            // Ajout des détails dans le fichier XML
            $data = $details->addChild('data');
            $data->addChild('service', $service);
            $data->addChild('pays', $pays);
            $data->addChild('motif', $motif);
            $data->addChild('nb_transaction_emission', $detail_nb_transaction_emission);
            $data->addChild('valeur_transaction_emission', $detail_valeur_transaction_emission);
            $data->addChild('nb_transaction_reception', $detail_nb_transaction_reception);
            $data->addChild('valeur_transaction_reception', $detail_valeur_transaction_reception);
        }

        // Insertion des détails dans la base de données
        $stmt->bind_param("ssiiissssiiii", $debutperiode, $finperiode, $nb_transaction_emission, $valeur_transaction_emission, $nb_transaction_reception, $valeur_transaction_reception, $service, $pays, $motif, $detail_nb_transaction_emission, $detail_valeur_transaction_emission, $detail_nb_transaction_reception, $detail_valeur_transaction_reception);
        $stmt->execute();
        
        echo "</ul>";
    } else {
        // Insertion des données de base sans détails
        $service = null;
        $pays = null;
        $motif = null;
        $detail_nb_transaction_emission = null;
        $detail_valeur_transaction_emission = null;
        $detail_nb_transaction_reception = null;
        $detail_valeur_transaction_reception = null;

        $stmt->bind_param("ssiiissssiiii", $debutperiode, $finperiode, $nb_transaction_emission, $valeur_transaction_emission, $nb_transaction_reception, $valeur_transaction_reception, $service, $pays, $motif, $detail_nb_transaction_emission, $detail_valeur_transaction_emission, $detail_nb_transaction_reception, $detail_valeur_transaction_reception);
        $stmt->execute();
    }
    echo "</fieldset>";
    echo "</div>";

    // Fermeture de la requête et de la connexion
    $stmt->close();
    $conn->close();

    // Enregistrement du fichier XML
    $dom = new DOMDocument('1.0');
$dom->preserveWhiteSpace = false;
$dom->formatOutput = true;
$dom->loadXML($xml->asXML());
// Nom du fichier XML
$xml_filename = "EME_CODEETABLISSEMENT_" . date("d_m_Y") . "_T_OPERATIONSTRA_1_XML.xml"; 
$dom->save($xml_filename);
    

}
?>
<script>
var numData = 1;

function ajouterService() {
    var detailsDiv = document.getElementById("details");

    var fieldset = document.createElement("fieldset");
    var legend = document.createElement("legend");
    legend.textContent = "Data " + numData;
    fieldset.appendChild(legend);

    var labelService = document.createElement("label");
    labelService.textContent = "Service:";
    var inputService = document.createElement("input");
    inputService.type = "text";
    inputService.name = "service[]";
    inputService.required = true;

    var labelPays = document.createElement("label");
    labelPays.textContent = "Pays:";
    var inputPays = document.createElement("input");
    inputPays.name = "pays[]";
    inputPays.required = true;

    var labelMotif = document.createElement("label");
    labelMotif.textContent = "Motif:";
    var inputMotif = document.createElement("input");
    inputMotif.name = "motif[]";
    inputMotif.required = true;

    var labelNbTransactionEmission = document.createElement("label");
    labelNbTransactionEmission.textContent = "Nombre de transactions émission:";
    var inputNbTransactionEmission = document.createElement("input");
    inputNbTransactionEmission.type = "number";
    inputNbTransactionEmission.name = "detail_nb_transaction_emission[]";
    inputNbTransactionEmission.required = true;

    var labelValeurTransactionEmission = document.createElement("label");
    labelValeurTransactionEmission.textContent = "Valeur de transactions émission:";
    var inputValeurTransactionEmission = document.createElement("input");
    inputValeurTransactionEmission.type = "number";
    inputValeurTransactionEmission.name = "detail_valeur_transaction_emission[]";
    inputValeurTransactionEmission.required = true;

    var labelNbTransactionReception = document.createElement("label");
    labelNbTransactionReception.textContent = "Nombre de transactions réception:";
    var inputNbTransactionReception = document.createElement("input");
    inputNbTransactionReception.type = "number";
    inputNbTransactionReception.name = "detail_nb_transaction_reception[]";
    inputNbTransactionReception.required = true;

    var labelValeurTransactionReception = document.createElement("label");
    labelValeurTransactionReception.textContent = "Valeur de transactions réception:";
    var inputValeurTransactionReception = document.createElement("input");
    inputValeurTransactionReception.type = "number";
    inputValeurTransactionReception.name = "detail_valeur_transaction_reception[]";
    inputValeurTransactionReception.required = true;

    fieldset.appendChild(labelService);
    fieldset.appendChild(inputService);
    fieldset.appendChild(document.createElement("br"));
    fieldset.appendChild(labelPays);
    fieldset.appendChild(inputPays);
    fieldset.appendChild(document.createElement("br"));
    fieldset.appendChild(labelMotif);
    fieldset.appendChild(inputMotif);
    fieldset.appendChild(document.createElement("br"));
    fieldset.appendChild(labelNbTransactionEmission);
    fieldset.appendChild(inputNbTransactionEmission);
    fieldset.appendChild(document.createElement("br"));
    fieldset.appendChild(labelValeurTransactionEmission);
    fieldset.appendChild(inputValeurTransactionEmission);
    fieldset.appendChild(document.createElement("br"));
    fieldset.appendChild(labelNbTransactionReception);
    fieldset.appendChild(inputNbTransactionReception);
    fieldset.appendChild(document.createElement("br"));
    fieldset.appendChild(labelValeurTransactionReception);
    fieldset.appendChild(inputValeurTransactionReception);
    var button = document.createElement('button');
        button.type = 'button';
        button.textContent = 'Supprimer';
        button.onclick = function() {
            detailsDiv.removeChild(fieldset);
        };

        fieldset.appendChild(button);

    detailsDiv.appendChild(fieldset);

    numData++;
}

</script>

</body>
</html>
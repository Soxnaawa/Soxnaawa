<!DOCTYPE html>
<html>
<head>
    <title>Incident Paiement</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <!-- Formulaire pour déclarer les réclamations de chèques -->
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
    <legend><h2>Incident Paiement</h2></legend>
        <fieldset>
            <legend><h2>Incident</h2></legend>
            <label for="debutperiode">Date de début</label><br>
            <input type="date" id="debutperiode" name="debutperiode" required><br>
            <label for="finperiode">Date de fin</label><br>
            <input type="date" id="finperiode" name="finperiode" required><br>
        </fieldset>
        <fieldset>
            <legend><h3>Détails des Incidents de Paiement</h3></legend>
            <div id="details">
                <!-- Les champs pour les détails des acquisitions de cartes seront générés ici par JavaScript -->
            </div>
            <button type="button" onclick="ajouterIncident()">Ajouter Incident de Paiement</button>
          
        </fieldset>
        <input type="submit" value="Soumettre">
    </form>
    <script>
    var numIncident = 1; // Initialisation du compteur d'incident

    function ajouterIncident() {
        var detailsDiv = document.getElementById('details');

        var fieldset = document.createElement('fieldset');
        var legend = document.createElement('legend');
        legend.textContent = 'Incident De Paiement ' + numIncident;
        fieldset.appendChild(legend);

        // Génération automatique du code du type de carte
        var typeCarteCode = 'IPCARTE_' + numIncident;

        var labelTypeCarteCode = document.createElement('label');
        labelTypeCarteCode.textContent = 'Code du Type de Carte';
        var inputTypeCarteCode = document.createElement('input');
        inputTypeCarteCode.type = 'text';
        inputTypeCarteCode.name = 'typecartecode[]';
        inputTypeCarteCode.value = typeCarteCode;
        inputTypeCarteCode.readOnly = false; // Pour empêcher la modification
        inputTypeCarteCode.required = true;

        var labelDescription = document.createElement('label');
        labelDescription.textContent = 'Description';
        var inputDescription = document.createElement('input');
        inputDescription.type = 'text';
        inputDescription.name = 'description[]';
        inputDescription.required = true;

        var labelNombreCarte = document.createElement('label');
        labelNombreCarte.textContent = 'Nombre Carte';
        var inputNombreCarte = document.createElement('input');
        inputNombreCarte.type = 'number';
        inputNombreCarte.name = 'nombrecarte[]';
        inputNombreCarte.required = true;

        var labelValeurCFA = document.createElement('label');
        labelValeurCFA.textContent = 'Valeur CFA';
        var inputValeurCFA = document.createElement('input');
        inputValeurCFA.type = 'number';
        inputValeurCFA.name = 'valeurcfa[]';
        inputValeurCFA.required = true;

        fieldset.appendChild(labelTypeCarteCode);
        fieldset.appendChild(inputTypeCarteCode);
        fieldset.appendChild(document.createElement('br'));

        fieldset.appendChild(labelDescription);
        fieldset.appendChild(inputDescription);
        fieldset.appendChild(document.createElement('br'));

        fieldset.appendChild(labelNombreCarte);
        fieldset.appendChild(inputNombreCarte);
        fieldset.appendChild(document.createElement('br'));

        fieldset.appendChild(labelValeurCFA);
        fieldset.appendChild(inputValeurCFA);
        fieldset.appendChild(document.createElement('br'));

        // Ajouter le bouton de retour
        var button = document.createElement('button');
        button.type = 'button';
        button.textContent = 'Supprimer';
        button.onclick = function() {
            detailsDiv.removeChild(fieldset);
        };

        fieldset.appendChild(button);
        detailsDiv.appendChild(fieldset);

        numIncident++; // Incrémentation du compteur d'incident pour la prochaine fois
    }
</script>


    <?php
    // Paramètres de connexion à la base de données
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "users";

    // Connexion à la base de données
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("Échec de la connexion : " . $conn->connect_error);
    }


    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Récupération des données soumises
        $debutperiode = $_POST["debutperiode"];
        $finperiode = $_POST["finperiode"];
        $typecartecode = $_POST["typecartecode"];
        $description = $_POST["description"];
        $nombrecarte = $_POST["nombrecarte"];
        $valeurcfa = $_POST["valeurcfa"];

        $totalNombre = array_sum($nombrecarte);
    $totalValeurCFA = array_sum($valeurcfa);

  // Afficher les données soumises
  echo "<div id='donneesSoumises'>";
  echo "<h2>Données Soumises</h2>";
  echo "<p><strong>Date de début :</strong> " . htmlspecialchars($debutperiode) . "</p>";
  echo "<p><strong>Date de fin :</strong> " . htmlspecialchars($finperiode) . "</p>";
  echo "<p><strong>total Nombre Carte : </strong>" . htmlspecialchars($totalNombre) . "</p>";
  echo "<p><strong>total Valeur CFA : </strong>" . htmlspecialchars($totalValeurCFA) . "</p>";
  echo "<h3>Détails des Incidents de Paiement</h3>";

  $stmt = $conn->prepare("INSERT INTO incidents_paiement (debutperiode, finperiode, typecartecode, description, nombrecarte, valeurcfa) VALUES (?, ?, ?, ?, ?, ?)");

  for ($i = 0; $i < count($typecartecode); $i++) {
      echo "<p><strong>Code du Type de Carte :</strong> " . htmlspecialchars($typecartecode[$i]) . "</p>";
      echo "<p><strong>Description :</strong> " . htmlspecialchars($description[$i]) . "</p>";
      echo "<p><strong>Nombre Carte :</strong> " . htmlspecialchars($nombrecarte[$i]) . "</p>";
      if (!empty($valeurcfa[$i])) {
          echo "<p><strong>Valeur CFA :</strong> " . htmlspecialchars($valeurcfa[$i]) . "</p>";
      }
      // Exécution de la requête pour chaque incident
for ($i = 0; $i < count($typecartecode); $i++) {
// Liaison des paramètres
$stmt->bind_param("ssssdd", $debutperiode, $finperiode, $typecartecode[$i], $description[$i], $nombrecarte[$i], $valeurcfa[$i]);

// Exécution de la requête
if (!$stmt->execute()) {
  echo "Erreur lors de l'insertion : " . $stmt->error;
}
}

}
echo "</div>";

// Fermeture de la requête
$stmt->close();
           // Générer le fichier XML
    $xml = new DOMDocument('1.0', 'UTF-8');
    $xml->formatOutput = true;
    

    // Élément racine <incidentpaiementcarte>
    $incidentpaiementcarte = $xml->createElement('incidentpaiementcarte');
    $xml->appendChild($incidentpaiementcarte);

    // Élément <incident>
    $incident = $xml->createElement('incident');
    $incidentpaiementcarte->appendChild($incident);

    // Ajouter les éléments <debutperiode> et <finperiode>
    $incident->appendChild($xml->createElement('debutperiode', $debutperiode));
    $incident->appendChild($xml->createElement('finperiode', $finperiode));

    // Calculer le total du nombre de cartes et de la valeur CFA
    
    // Ajouter les éléments <totalnombre> et <totalvaleurcfa>
    $incident->appendChild($xml->createElement('totalnombre', $totalNombre));
    $incident->appendChild($xml->createElement('totalvaleurcfa', $totalValeurCFA));

    // Élément <details>
    $details = $xml->createElement('details');
    $incidentpaiementcarte->appendChild($details);

    // Ajouter les détails des incidents de paiement
    for ($i = 0; $i < count($typecartecode); $i++) {
        $typenomenclature = $xml->createElement('typenomenclature');
        $typenomenclature->setAttribute('code', $typecartecode[$i]);

        $descriptionElem = $xml->createElement('description');
        $descriptionElem->appendChild($xml->createCDATASection($description[$i]));
        $typenomenclature->appendChild($descriptionElem);

        $nbcarteElem = $xml->createElement('nbcarte', $nombrecarte[$i]);
        $typenomenclature->appendChild($nbcarteElem);

        // Vérifier si la valeur CFA est définie pour l'élément
        if (!empty($valeurcfa[$i])) {
            $valeurcfaElem = $xml->createElement('valeurcfa', $valeurcfa[$i]);
            $typenomenclature->appendChild($valeurcfaElem);
        }
        $details->appendChild($typenomenclature);
    }
    
    // Créer la période de référence
    $refperiode = date('Ym', strtotime($debutperiode)) . '-' . date('Ym', strtotime($finperiode));

    // Générer le nom du fichier en utilisant la nomenclature spécifiée
  //  $xml_filename = "EME_CODEETABLISSEMENT_{$refperiode}_S_INCIDENTPAIEMENTCARTE_1_XML.XML";
   // $xml->save($xml_filename);
       
 
   $codeEmetteur = "CODEETABLISSEMENT"; // Remplacez par la valeur appropriée
   $refPeriode = date("d_m_Y");
   $frequence = "S"; // Exemple, remplacez par la valeur appropriée
   $codeBranche = "INCIDENTPAIEMENT"; // Remplacez par la valeur appropriée

   // Déterminer la version du fichier
   $version = 1;
   $baseFilename = "EME_{$codeEmetteur}_{$refPeriode}_{$frequence}_{$codeBranche}_";
   $directory = __DIR__; // Répertoire actuel
   $files = glob($directory . "/" . $baseFilename . "*.xml");

   if ($files) {
       // Extraire les numéros de version des fichiers existants et déterminer le prochain numéro de version
       $maxVersion = 0;
       foreach ($files as $file) {
           if (preg_match('/_(\d+)_XML\.XML$/', $file, $matches)) {
               $fileVersion = (int)$matches[1];
               if ($fileVersion > $maxVersion) {
                   $maxVersion = $fileVersion;
               }
           }
       }
       $version = $maxVersion + 1;
   }

   $xml_filename = "{$baseFilename}{$version}_XML.XML";
   $xml->save($xml_filename);

         // Afficher le message de succès avec un lien vers le fichier XML
         echo "<div style='font-family: Arial, sans-serif; text-align: center; margin-top: 10px; padding: 30px;'>";
         echo "<h2 style='color: #008a50;'>Les informations ont été enregistrées.</h2>";
         echo "<a href='$xml_filename'>Télécharger le fichier XML</a><br>";
         echo "</div>";
}
         $conn->close();
    ?>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <title>Incident Cheque Carte</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <fieldset>
        <legend><h2>Incident Cheque Carte</h2></legend>
        <label for="debutperiode">Début de période:</label><br>
        <input type="date" id="debutperiode" name="debutperiode" required><br>
        <label for="finperiode">Fin de période:</label><br>
        <input type="date" id="finperiode" name="finperiode" required><br>
        <label for="totalincidents">Total des Incidents:</label><br>
        <input type="number" id="totalincidents" name="totalincidents" required><br>
        <label for="totalimpactfinancier">Total Impact Financier:</label><br>
        <input type="number" id="totalimpactfinancier" name="totalimpactfinancier" required><br>
    </fieldset>

    <div id="details"></div>

    <button type="button" onclick="ajouterdonneecarte()">Ajouter donnée Carte</button>
   
    <input type="submit" value="Soumettre">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connexion à la base de données
    $servername = "localhost"; // À adapter selon votre configuration
    $username = "root"; // À adapter selon votre configuration
    $password = ""; // À adapter selon votre configuration
    $dbname = "users"; // À adapter selon votre configuration

    // Création de la connexion
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérification de la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Préparation de la requête d'insertion
    $stmt = $conn->prepare("INSERT INTO incidentchequecarte (debutperiode, finperiode, totalincidents, totalimpactfinancier, data_type, dateincident, libelleincident, risque, nboccurrence, descriptiondetaillee, mesurescorrectives, impactfinancier, statutincident, datecloture, infoscomplementaires) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    if (!$stmt) {
        die("Preparation failed: " . $conn->error);
    }

    $debutperiode = $_POST['debutperiode'];
    $finperiode = $_POST['finperiode'];
    $totalincidents = $_POST['totalincidents'];
    $totalimpactfinancier = $_POST['totalimpactfinancier'];

    echo "<div id='donneesSoumises'>";
    echo "<h2>Données soumises :</h2>";
    echo "<fieldset>";
    echo "<p>Début de période : " . htmlspecialchars($debutperiode) . "</p>";
    echo "<p>Fin de période : " . htmlspecialchars($finperiode) . "</p>";
    echo "<p>Total des Incidents : " . htmlspecialchars($totalincidents) . "</p>";
    echo "<p>Total Impact Financier : " . htmlspecialchars($totalimpactfinancier) . "</p>";

    // Création de l'objet XML
    $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><incidentchequecarte/>');
    $incident = $xml->addChild('incident');
    $incident->addChild('debutperiode', $debutperiode);
    $incident->addChild('finperiode', $finperiode);
    $incident->addChild('totalincidents', $totalincidents);
    $incident->addChild('totalimpactfinancier', $totalimpactfinancier);

    $details = $xml->addChild('details');

   // $stmt->bind_param("ssiiisssssssssss", $debutperiode, $finperiode, $totalincidents, $totalimpactfinancier, $data_type, $dateincident, $libelleincident, $risque, $nboccurrence, $descriptiondetaillee, $mesurescorrectives, $impactfinancier, $statutincident, $datecloture, $infoscomplementaires);
   $stmt->bind_param("ssiissssississs", $debutperiode, $finperiode, $totalincidents, $totalimpactfinancier, $data_type, $dateincident, $libelleincident, $risque, $nboccurrence, $descriptiondetaillee, $mesurescorrectives, $impactfinancier, $statutincident, $datecloture, $infoscomplementaires);
    
    $stmt->execute();

    if (!empty($_POST['data_type'])) {
        echo "<h3>Details :</h3>";
        echo "<ul>";
        foreach ($_POST['data_type'] as $key => $value) {
            $data_type = !empty($_POST['data_type'][$key]) ? $_POST['data_type'][$key] : null;
            $dateincident = !empty($_POST['dateincident'][$key]) ? $_POST['dateincident'][$key] : null;
            $libelleincident = !empty($_POST['libelleincident'][$key]) ? $_POST['libelleincident'][$key] : null;
            $risque = !empty($_POST['risque'][$key]) ? $_POST['risque'][$key] : null;
            $nboccurrence = !empty($_POST['nboccurrence'][$key]) ? $_POST['nboccurrence'][$key] : null;
            $descriptiondetaillee = !empty($_POST['descriptiondetaillee'][$key]) ? $_POST['descriptiondetaillee'][$key] : null;
            $mesurescorrectives = !empty($_POST['mesurescorrectives'][$key]) ? $_POST['mesurescorrectives'][$key] : null;
            $impactfinancier = !empty($_POST['impactfinancier'][$key]) ? $_POST['impactfinancier'][$key] : null;
            $statutincident = !empty($_POST['statutincident'][$key]) ? $_POST['statutincident'][$key] : null;
            $datecloture = !empty($_POST['datecloture'][$key]) ? $_POST['datecloture'][$key] : null;
            $infoscomplementaires = !empty($_POST['infoscomplementaires'][$key]) ? $_POST['infoscomplementaires'][$key] : null;

            echo "<li>Donnée Carte " . ($key + 1) . "</li>";
            echo "<ul>";
            echo "<li>Type Donnée : " . htmlspecialchars($data_type) . "</li>";
            echo "<li>Date Incident : " . htmlspecialchars($dateincident) . "</li>";
            echo "<li>Libelle Incident : " . htmlspecialchars($libelleincident) . "</li>";
            echo "<li>Risque : " . htmlspecialchars($risque) . "</li>";
            echo "<li>Nombre Occurrence : " . htmlspecialchars($nboccurrence) . "</li>";
            echo "<li>Description Detaillee : " . htmlspecialchars($descriptiondetaillee) . "</li>";
            echo "<li>Mesures Correctives : " . htmlspecialchars($mesurescorrectives) . "</li>";
            echo "<li>Impact Financier : " . htmlspecialchars($impactfinancier) . "</li>";
            echo "<li>Statut Incident : " . htmlspecialchars($statutincident) . "</li>";
            echo "<li>Date de Cloture : " . htmlspecialchars($datecloture) . "</li>";
            echo "<li>Informations Complementaires : " . htmlspecialchars($infoscomplementaires) . "</li>";
            echo "</ul>";

            // Ajout des détails dans le fichier XML
            $data = $details->addChild('data');
            $data->addAttribute('type', $data_type);
            $data->addChild('dateincident', $dateincident);
            $data->addChild('libelleincident', $libelleincident);
            $data->addChild('risque', $risque);
            $data->addChild('nboccurrence', $nboccurrence);
            $data->addChild('descriptiondetaillee', $descriptiondetaillee);
            $data->addChild('mesurescorrectives', $mesurescorrectives);
            $data->addChild('impactfinancier', $impactfinancier);
            $data->addChild('statutincident', $statutincident);
            $data->addChild('datecloture', $datecloture);
            $data->addChild('infoscomplementaires', $infoscomplementaires);

            // Insertion des détails dans la base de données
            //$stmt->bind_param("ssissssssssisss", $debutperiode, $finperiode, $totalincidents, $totalimpactfinancier, $data_type, $dateincident, $libelleincident, $risque, $nboccurrence, $descriptiondetaillee, $mesurescorrectives, $impactfinancier, $statutincident, $datecloture, $infoscomplementaires);
            $stmt->execute();
        }
        echo "</ul>";
    }
    echo "</fieldset>";
    echo "</div>";

    // Fermeture de la requête et de la connexion
    $stmt->close();
    $conn->close();

    // Enregistrement du fichier XML
    $dom = new DOMDocument('1.0');
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    $dom->loadXML($xml->asXML());
    // Nom du fichier XML
    $xml_filename = "EME_CODEETABLISSEMENT_" . date("d_m_Y") . "_S_INCIDENTCHEQUECARTE_1_XML.xml";
    $dom->save($xml_filename);
}
?>

<script>
var numData = 1;

function ajouterdonneecarte() {
    var detailsDiv = document.getElementById("details");

    var fieldset = document.createElement("fieldset");
    var legend = document.createElement("legend");
    legend.textContent = "Données Carte " + numData;
    fieldset.appendChild(legend);

    var labeldata_type = document.createElement("label");
    labeldata_type.setAttribute("for", "data_type_" + numData);
    labeldata_type.textContent = "Type Donnée:";
    fieldset.appendChild(labeldata_type);
    var inputdata_type = document.createElement("input");
    inputdata_type.type = "text";
    inputdata_type.id = "data_type_" + numData;
    inputdata_type.name = "data_type[]";
    fieldset.appendChild(inputdata_type);
    fieldset.appendChild(document.createElement("br"));

    var labeldateincident = document.createElement("label");
    labeldateincident.setAttribute("for", "dateincident_" + numData);
    labeldateincident.textContent = "Date Incident:";
    fieldset.appendChild(labeldateincident);
    var inputdateincident = document.createElement("input");
    inputdateincident.type = "date";
    inputdateincident.id = "dateincident_" + numData;
    inputdateincident.name = "dateincident[]";
    fieldset.appendChild(inputdateincident);
    fieldset.appendChild(document.createElement("br"));

    var labellibelleincident = document.createElement("label");
    labellibelleincident.setAttribute("for", "libelleincident_" + numData);
    labellibelleincident.textContent = "Libelle Incident:";
    fieldset.appendChild(labellibelleincident);
    var inputlibelleincident = document.createElement("input");
    inputlibelleincident.type = "text";
    inputlibelleincident.id = "libelleincident_" + numData;
    inputlibelleincident.name = "libelleincident[]";
    fieldset.appendChild(inputlibelleincident);
    fieldset.appendChild(document.createElement("br"));

    var labelrisque = document.createElement("label");
    labelrisque.setAttribute("for", "risque_" + numData);
    labelrisque.textContent = "Risque:";
    fieldset.appendChild(labelrisque);
    var inputrisque = document.createElement("input");
    inputrisque.type = "text";
    inputrisque.id = "risque_" + numData;
    inputrisque.name = "risque[]";
    fieldset.appendChild(inputrisque);
    fieldset.appendChild(document.createElement("br"));

    var labelnboccurrence = document.createElement("label");
    labelnboccurrence.setAttribute("for", "nboccurrence_" + numData);
    labelnboccurrence.textContent = "Nombre Occurrence:";
    fieldset.appendChild(labelnboccurrence);
    var inputnboccurrence = document.createElement("input");
    inputnboccurrence.type = "number";
    inputnboccurrence.id = "nboccurrence_" + numData;
    inputnboccurrence.name = "nboccurrence[]";
    fieldset.appendChild(inputnboccurrence);
    fieldset.appendChild(document.createElement("br"));

    var labeldescriptiondetaillee = document.createElement("label");
    labeldescriptiondetaillee.setAttribute("for", "descriptiondetaillee_" + numData);
    labeldescriptiondetaillee.textContent = "Description Detaillée:";
    fieldset.appendChild(labeldescriptiondetaillee);
    var inputdescriptiondetaillee = document.createElement("textarea");
    inputdescriptiondetaillee.id = "descriptiondetaillee_" + numData;
    inputdescriptiondetaillee.name = "descriptiondetaillee[]";
    fieldset.appendChild(inputdescriptiondetaillee);
    fieldset.appendChild(document.createElement("br"));

    var labelmesurescorrectives = document.createElement("label");
    labelmesurescorrectives.setAttribute("for", "mesurescorrectives_" + numData);
    labelmesurescorrectives.textContent = "Mesures Correctives:";
    fieldset.appendChild(labelmesurescorrectives);
    var inputmesurescorrectives = document.createElement("textarea");
    inputmesurescorrectives.id = "mesurescorrectives_" + numData;
    inputmesurescorrectives.name = "mesurescorrectives[]";
    fieldset.appendChild(inputmesurescorrectives);
    fieldset.appendChild(document.createElement("br"));

    var labelimpactfinancier = document.createElement("label");
    labelimpactfinancier.setAttribute("for", "impactfinancier_" + numData);
    labelimpactfinancier.textContent = "Impact Financier:";
    fieldset.appendChild(labelimpactfinancier);
    var inputimpactfinancier = document.createElement("input");
    inputimpactfinancier.type = "number";
    inputimpactfinancier.id = "impactfinancier_" + numData;
    inputimpactfinancier.name = "impactfinancier[]";
    fieldset.appendChild(inputimpactfinancier);
    fieldset.appendChild(document.createElement("br"));

    var labelstatutincident = document.createElement("label");
    labelstatutincident.setAttribute("for", "statutincident_" + numData);
    labelstatutincident.textContent = "Statut Incident:";
    fieldset.appendChild(labelstatutincident);
    var inputstatutincident = document.createElement("input");
    inputstatutincident.type = "text";
    inputstatutincident.id = "statutincident_" + numData;
    inputstatutincident.name = "statutincident[]";
    fieldset.appendChild(inputstatutincident);
    fieldset.appendChild(document.createElement("br"));

    var labeldatecloture = document.createElement("label");
    labeldatecloture.setAttribute("for", "datecloture_" + numData);
    labeldatecloture.textContent = "Date de Cloture:";
    fieldset.appendChild(labeldatecloture);
    var inputdatecloture = document.createElement("input");
    inputdatecloture.type = "date";
    inputdatecloture.id = "datecloture_" + numData;
    inputdatecloture.name = "datecloture[]";
    fieldset.appendChild(inputdatecloture);
    fieldset.appendChild(document.createElement("br"));

    var labelinfoscomplementaires = document.createElement("label");
    labelinfoscomplementaires.setAttribute("for", "infoscomplementaires_" + numData);
    labelinfoscomplementaires.textContent = "Informations Complementaires:";
    fieldset.appendChild(labelinfoscomplementaires);
    var inputinfoscomplementaires = document.createElement("textarea");
    inputinfoscomplementaires.id = "infoscomplementaires_" + numData;
    inputinfoscomplementaires.name = "infoscomplementaires[]";
    fieldset.appendChild(inputinfoscomplementaires);
    fieldset.appendChild(document.createElement("br"));
    var button = document.createElement('button');
        button.type = 'button';
        button.textContent = 'Supprimer';
        button.onclick = function() {
            detailsDiv.removeChild(fieldset);
        };

        fieldset.appendChild(button);
    detailsDiv.appendChild(fieldset);

    numData++;
}

</script>
</body>
</html>
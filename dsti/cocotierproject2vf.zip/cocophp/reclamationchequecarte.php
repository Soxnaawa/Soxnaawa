<!DOCTYPE html>
<html>
<head>
<title>Reclamation Cheque Carte</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<!-- Formulaire pour déclarer les réclamations de chèques -->
<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
<legend><h2>Réclamation de Chèque et de Carte</h2></legend>
<fieldset>
<legend><h2>Réclamation</h2></legend>
<label for="debutperiode">Date de début</label><br>
<input type="date" id="debutperiode" name="debutperiode" required><br>
<label for="finperiode">Date de fin</label><br>
<input type="date" id="finperiode" name="finperiode" required><br>
</fieldset>
<fieldset>
<legend><h3>Détails des Réclamations de Chèques</h3></legend>
<div id="details_cheque">
<!-- Les champs pour les détails des réclamations de chèques seront générés ici par JavaScript -->
</div>
<button type="button" onclick="ajouterReclamationCheque()">Ajouter Réclamation de Chèque</button>
</fieldset>

<!-- Formulaire pour déclarer les réclamations de cartes -->
<fieldset>
<legend><h3>Détails des Réclamations de Carte</h3></legend>
<div id="details_carte">
<!-- Les champs pour les détails des réclamations de cartes seront générés ici par JavaScript -->
</div>
<button type="button" onclick="ajouterReclamationCarte()">Ajouter Réclamation de Carte</button>
</fieldset>

<input type="submit" value="Soumettre">
</form>
<script>
function ajouterReclamationCheque() {
var detailsDiv = document.getElementById('details_cheque');
var numReclamation = detailsDiv.getElementsByTagName('fieldset').length + 1;

var fieldset = document.createElement('fieldset');
var legend = document.createElement('legend');
legend.textContent = 'Réclamation de Chèque ' + numReclamation;
fieldset.appendChild(legend);

var labelMotif = document.createElement('label');
labelMotif.textContent = 'Motif';
var inputMotif = document.createElement('textarea');
inputMotif.name = 'motif_cheque[]';
inputMotif.required = true;

var labelEtatTraitement = document.createElement('label');
labelEtatTraitement.textContent = 'État de Traitement';
var inputEtatTraitement = document.createElement('input');
inputEtatTraitement.type = 'text';
inputEtatTraitement.name = 'etattraitement_cheque[]';
inputEtatTraitement.required = true;

var labelMesuresCorrectives = document.createElement('label');
labelMesuresCorrectives.textContent = 'Mesures Correctives';
var inputMesuresCorrectives = document.createElement('textarea');
inputMesuresCorrectives.name = 'mesurescorrectives_cheque[]';
inputMesuresCorrectives.required = true;

var labelNombre = document.createElement('label');
labelNombre.textContent = 'Nombre';
var inputNombre = document.createElement('input');
inputNombre.type = 'number';
inputNombre.name = 'nombre_cheque[]';
inputNombre.required = true;

var buttonSupprimer = document.createElement('button');
buttonSupprimer.type = 'button';
buttonSupprimer.textContent = 'Supprimer';
buttonSupprimer.onclick = function() {
detailsDiv.removeChild(fieldset);
};

fieldset.appendChild(labelMotif);
fieldset.appendChild(inputMotif);
fieldset.appendChild(document.createElement('br'));
fieldset.appendChild(labelEtatTraitement);
fieldset.appendChild(inputEtatTraitement);
fieldset.appendChild(document.createElement('br'));
fieldset.appendChild(labelMesuresCorrectives);
fieldset.appendChild(inputMesuresCorrectives);
fieldset.appendChild(document.createElement('br'));
fieldset.appendChild(labelNombre);
fieldset.appendChild(inputNombre);
fieldset.appendChild(document.createElement('br'));
fieldset.appendChild(buttonSupprimer);

detailsDiv.appendChild(fieldset);
}

function ajouterReclamationCarte() {
var detailsDiv = document.getElementById('details_carte');
var numReclamation = detailsDiv.getElementsByTagName('fieldset').length + 1;

var fieldset = document.createElement('fieldset');
var legend = document.createElement('legend');
legend.textContent = 'Réclamation de Carte ' + numReclamation;
fieldset.appendChild(legend);

var labelMotif = document.createElement('label');
labelMotif.textContent = 'Motif';
var inputMotif = document.createElement('textarea');
inputMotif.name = 'motif_carte[]';
inputMotif.required = true;

var labelEtatTraitement = document.createElement('label');
labelEtatTraitement.textContent = 'État de Traitement';
var inputEtatTraitement = document.createElement('input');
inputEtatTraitement.type = 'text';
inputEtatTraitement.name = 'etattraitement_carte[]';
inputEtatTraitement.required = true;

var labelMesuresCorrectives = document.createElement('label');
labelMesuresCorrectives.textContent = 'Mesures Correctives';
var inputMesuresCorrectives = document.createElement('textarea');
inputMesuresCorrectives.name = 'mesurescorrectives_carte[]';
inputMesuresCorrectives.required = true;

var labelNombre = document.createElement('label');
labelNombre.textContent = 'Nombre';
var inputNombre = document.createElement('input');
inputNombre.type = 'number';
inputNombre.name = 'nombre_carte[]';
inputNombre.required = true;

var buttonSupprimer = document.createElement('button');
buttonSupprimer.type = 'button';
buttonSupprimer.textContent = 'Supprimer';
buttonSupprimer.onclick = function() {
detailsDiv.removeChild(fieldset);
};

fieldset.appendChild(labelMotif);
fieldset.appendChild(inputMotif);
fieldset.appendChild(document.createElement('br'));
fieldset.appendChild(labelEtatTraitement);
fieldset.appendChild(inputEtatTraitement);
fieldset.appendChild(document.createElement('br'));
fieldset.appendChild(labelMesuresCorrectives);
fieldset.appendChild(inputMesuresCorrectives);
fieldset.appendChild(document.createElement('br'));
fieldset.appendChild(labelNombre);
fieldset.appendChild(inputNombre);
fieldset.appendChild(document.createElement('br'));
fieldset.appendChild(buttonSupprimer);

detailsDiv.appendChild(fieldset);
}
</script>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";

$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
die("Échec de la connexion : " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
// Récupérer les données soumises du formulaire
$debutperiode = $_POST['debutperiode'];
$finperiode = $_POST['finperiode'];

// Initialiser les variables pour les réclamations de chèques
$motif_cheque = isset($_POST['motif_cheque']) ? $_POST['motif_cheque'] : [];
$etattraitement_cheque = isset($_POST['etattraitement_cheque']) ? $_POST['etattraitement_cheque'] : [];
$mesurescorrectives_cheque = isset($_POST['mesurescorrectives_cheque']) ? $_POST['mesurescorrectives_cheque'] : [];
$nombre_cheque = isset($_POST['nombre_cheque']) ? $_POST['nombre_cheque'] : [];

// Initialiser les variables pour les réclamations de cartes
$motif_carte = isset($_POST['motif_carte']) ? $_POST['motif_carte'] : [];
$etattraitement_carte = isset($_POST['etattraitement_carte']) ? $_POST['etattraitement_carte'] : [];
$mesurescorrectives_carte = isset($_POST['mesurescorrectives_carte']) ? $_POST['mesurescorrectives_carte'] : [];
$nombre_carte = isset($_POST['nombre_carte']) ? $_POST['nombre_carte'] : [];

// Afficher les données soumises
echo "<div id='donneesSoumises'>";
echo "<h2>Données Soumises :</h2>";
echo "<p>Date de début : " . htmlspecialchars($debutperiode) . "</p>";
echo "<p>Date de fin : " . htmlspecialchars($finperiode) . "</p>";

if (!empty($motif_cheque)) {
echo "<h3>Détails des Réclamations de Chèques :</h3>";
for ($i = 0; $i < count($motif_cheque); $i++) {
echo "<p>Réclamation " . ($i + 1) . " :</p>";
echo "<p>Motif : " . htmlspecialchars($motif_cheque[$i]) . "</p>";
echo "<p>État de Traitement : " . htmlspecialchars($etattraitement_cheque[$i]) . "</p>";
echo "<p>Mesures Correctives : " . htmlspecialchars($mesurescorrectives_cheque[$i]) . "</p>";
echo "<p>Nombre : " . htmlspecialchars($nombre_cheque[$i]) . "</p>";
}
for ($i = 0; $i < count($motif_cheque); $i++) {
$sql = "INSERT INTO reclamations_cheque (debutperiode, finperiode, motif, etattraitement, mesurescorrectives, nombre) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssi", $debutperiode, $finperiode, $motif_cheque[$i], $etattraitement_cheque[$i], $mesurescorrectives_cheque[$i], $nombre_cheque[$i]);
$stmt->execute();
$stmt->close();
}
}

if (!empty($motif_carte)) {
echo "<h3>Détails des Réclamations de Cartes :</h3>";
for ($i = 0; $i < count($motif_carte); $i++) {
echo "<p>Réclamation " . ($i + 1) . " :</p>";
echo "<p>Motif : " . htmlspecialchars($motif_carte[$i]) . "</p>";
echo "<p>État de Traitement : " . htmlspecialchars($etattraitement_carte[$i]) . "</p>";
echo "<p>Mesures Correctives : " . htmlspecialchars($mesurescorrectives_carte[$i]) . "</p>";
echo "<p>Nombre : " . htmlspecialchars($nombre_carte[$i]) . "</p>";
}
for ($i = 0; $i < count($motif_carte); $i++) {
$sql = "INSERT INTO reclamations_carte (debutperiode, finperiode, motif, etattraitement, mesurescorrectives, nombre) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssi", $debutperiode, $finperiode, $motif_carte[$i], $etattraitement_carte[$i], $mesurescorrectives_carte[$i], $nombre_carte[$i]);
$stmt->execute();
$stmt->close();
}
}

echo "</div>";

// Générer le fichier XML
$xml = new DOMDocument('1.0', 'UTF-8');
$xml->formatOutput = true;

// Élément racine <reclamationchequecarte>
$reclamationchequecarte = $xml->createElement('reclamationchequecarte');
$xml->appendChild($reclamationchequecarte);

// Élément <reclamation>
$reclamation = $xml->createElement('reclamation');
$reclamationchequecarte->appendChild($reclamation);

$reclamation->appendChild($xml->createElement('debutperiode', $debutperiode));
$reclamation->appendChild($xml->createElement('finperiode', $finperiode));

$totalcarte = array_sum($nombre_carte);
$totalcheque = array_sum($nombre_cheque);
$reclamation->appendChild($xml->createElement('totalcarte', $totalcarte));
$reclamation->appendChild($xml->createElement('totalcheque', $totalcheque));

// Élément <details>
$detailsElem = $xml->createElement('details');
$reclamationchequecarte->appendChild($detailsElem);

// Itérer sur les réclamations de cartes
for ($i = 0; $i < count($motif_carte); $i++) {
$carteElem = $xml->createElement('cartes');

$dataElem = $xml->createElement('data');
$carteElem->appendChild($dataElem);

$dataElem->appendChild($xml->createElement('motif', $motif_carte[$i]));
$dataElem->appendChild($xml->createElement('etattraitement', $etattraitement_carte[$i]));
$dataElem->appendChild($xml->createElement('mesurescorrectives', $mesurescorrectives_carte[$i]));
$dataElem->appendChild($xml->createElement('nbre', $nombre_carte[$i]));
$detailsElem->appendChild($carteElem);
}

// Itérer sur les réclamations de chèques
for ($i = 0; $i < count($motif_cheque); $i++) {
$chequeElem = $xml->createElement('cheques');

$dataElem = $xml->createElement('data');
$chequeElem->appendChild($dataElem);

$dataElem->appendChild($xml->createElement('motif', $motif_cheque[$i]));
$dataElem->appendChild($xml->createElement('etattraitement', $etattraitement_cheque[$i]));
$dataElem->appendChild($xml->createElement('mesurescorrectives', $mesurescorrectives_cheque[$i]));
$dataElem->appendChild($xml->createElement('nbre', $nombre_cheque[$i]));

$detailsElem->appendChild($chequeElem);
}

// Construire le nom de fichier selon la nomenclature
$codeEmetteur = "CODEETABLISSEMENT"; // Remplacez par la valeur appropriée
$refPeriode = date("d_m_Y");
$frequence = "S"; // Exemple, remplacez par la valeur appropriée
$codeBranche = "RECLAMATIONCHEQUECARTE"; // Remplacez par la valeur appropriée

// Déterminer la version du fichier
$version = 1;
$baseFilename = "EME_{$codeEmetteur}_{$refPeriode}_{$frequence}_{$codeBranche}_";
$directory = __DIR__; // Répertoire actuel
$files = glob($directory . "/" . $baseFilename . "*.xml");

if ($files) {
// Extraire les numéros de version des fichiers existants et déterminer le prochain numéro de version
$maxVersion = 0;
foreach ($files as $file) {
if (preg_match('/_(\d+)_XML\.XML$/', $file, $matches)) {
$fileVersion = (int)$matches[1];
if ($fileVersion > $maxVersion) {
$maxVersion = $fileVersion;
}
}
}
$version = $maxVersion + 1;
}

$xml_filename = "{$baseFilename}{$version}_XML.XML";
$xml->save($xml_filename);

// Afficher le message de succès avec un lien vers le fichier XML
echo "<div style='font-family: Arial, sans-serif; text-align: center; margin-top: 10px; padding: 30px;'>";
echo "<h2 style='color: #008a50;'>Les informations ont été enregistrées.</h2>";
echo "<a href='$xml_filename' style='text-decoration: none; color: #008a50;'>Télécharger le fichier XML</a>";
echo "</div>";
}

// Fermer la connexion
$conn->close();
?>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
    <title>Emission Carte</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <fieldset>
        <legend><h2>Emission Carte</h2></legend>
        <label for="debutperiode">Début de période:</label><br>
        <input type="date" id="debutperiode" name="debutperiode" required><br>
        <label for="finperiode">Fin de période:</label><br>
        <input type="date" id="finperiode" name="finperiode" required><br>
        <label for="totalcarte">Total Carte:</label><br>
        <input type="text" id="totalcarte" name="totalcarte" required><br>
    </fieldset>

    <div id="details"></div>

    <button type="button" onclick="ajouterfamillecarte()">Ajouter Famille Carte</button>
    

    <input type="submit" value="Soumettre">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connexion à la base de données
    $servername = "localhost"; // À adapter selon votre configuration
    $username = "root"; // À adapter selon votre configuration
    $password = ""; // À adapter selon votre configuration
    $dbname = "users"; // À adapter selon votre configuration

    // Création de la connexion
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérification de la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Préparation de la requête d'insertion
    $stmt = $conn->prepare("INSERT INTO emissioncarte (debutperiode, finperiode, totalcarte, famillecarte_code, famillecarte_total, typecarte_code, typecarte_description, typecarte_nbcarte) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

    $debutperiode = $_POST['debutperiode'];
    $finperiode = $_POST['finperiode'];
    $totalcarte = $_POST['totalcarte'];

    echo "<div id='donneesSoumises'>";
    echo "<h2>Données soumises :</h2>";
    echo "<fieldset>";
    echo "<legend>Informations soumises</legend>";
    echo "<p>Début de période : " . $debutperiode . "</p>";
    echo "<p>Fin de période : " . $finperiode . "</p>";
    echo "<p>Nombre de transactions émission : " . $totalcarte . "</p>";

    // Création de l'objet XML
    $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><emissioncarte/>');
    $emission = $xml->addChild('emission');
    $emission->addChild('debutperiode', $debutperiode);
    $emission->addChild('finperiode', $finperiode);
    $emission->addChild('totalcarte', $totalcarte);

    $details = $xml->addChild('details');

    if (!empty($_POST['famillecarte_code'])) {
        echo "<h3>Details :</h3>";
        echo "<ul>";
        foreach ($_POST['famillecarte_code'] as $key => $value) {
            $famillecarte_code = !empty($_POST['famillecarte_code'][$key]) ? $_POST['famillecarte_code'][$key] : null;
            $famillecarte_total = !empty($_POST['famillecarte_total'][$key]) ? $_POST['famillecarte_total'][$key] : null;
            $typecarte_code = !empty($_POST['typecarte_code'][$key]) ? $_POST['typecarte_code'][$key] : null;
            $typecarte_description = !empty($_POST['typecarte_description'][$key]) ? $_POST['typecarte_description'][$key] : null;
            $typecarte_nbcarte = !empty($_POST['typecarte_nbcarte'][$key]) ? $_POST['typecarte_nbcarte'][$key] : null;

            echo "<li>Famille Carte " . ($key + 1) . "</li>";
            echo "<ul>";
            echo "<li>famillecarte_code : " . $famillecarte_code . "</li>";
            echo "<li>famillecarte_total : " . $famillecarte_total . "</li>";
            echo "<li>typecarte_code : " . $typecarte_code . "</li>";
            echo "<li>typecarte_description : " . $typecarte_description . "</li>";
            echo "<li>typecarte_nbcarte : " . $typecarte_nbcarte . "</li>";
            echo "</ul>";

            // Ajout des détails dans le fichier XML
            $famillecarte = $details->addChild('famillecarte');
            $famillecarte->addAttribute('famillecarte_code', $famillecarte_code);
            $famillecarte->addAttribute('famillecarte_total', $famillecarte_total);
            $typecarte = $famillecarte->addChild('typecarte');
            $typecarte->addAttribute('typecarte_code', $typecarte_code);
            $typecarte->addChild('typecarte_description', $typecarte_description);
            $typecarte->addChild('typecarte_nbcarte', $typecarte_nbcarte);

            // Insertion des détails dans la base de données
            $stmt->bind_param("ssisssss", $debutperiode, $finperiode, $totalcarte, $famillecarte_code, $famillecarte_total, $typecarte_code, $typecarte_description, $typecarte_nbcarte);
            $stmt->execute();
        }
        echo "</ul>";
    } else {
        // Insertion des données de base sans détails
        $famillecarte_code = null;
        $famillecarte_total = null;
        $typecarte_code = null;
        $typecarte_description = null;
        $typecarte_nbcarte = null;

        $stmt->bind_param("ssisssss", $debutperiode, $finperiode, $totalcarte, $famillecarte_code, $famillecarte_total, $typecarte_code, $typecarte_description, $typecarte_nbcarte);
        $stmt->execute();
    }
    echo "</fieldset>";
    echo "</div>";

    // Fermeture de la requête et de la connexion
    $stmt->close();
    $conn->close();

    // Enregistrement du fichier XML
    $dom = new DOMDocument('1.0');
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    $dom->loadXML($xml->asXML());
    // Nom du fichier XML
    $xml_filename = "EME_CODEETABLISSEMENT_" . date("d_m_Y") . "_S_EMCARTE_1_XML.xml";
    $dom->save($xml_filename);
}
?>
<script>
var numData = 1;

function ajouterfamillecarte() {
    var detailsDiv = document.getElementById("details");

    var fieldset = document.createElement("fieldset");
    var legend = document.createElement("legend");
    legend.textContent = "Famille Carte " + numData;
    fieldset.appendChild(legend);

    var labelfamillecarte_code = document.createElement("label");
    labelfamillecarte_code.textContent = "Code Famille Carte :";
    var inputfamillecarte_code = document.createElement("input");
    inputfamillecarte_code.type = "text";
    inputfamillecarte_code.name = "famillecarte_code[]";
    inputfamillecarte_code.required = true;

    var labelfamillecarte_total = document.createElement("label");
    labelfamillecarte_total.textContent = "Total Famille Carte :";
    var inputfamillecarte_total = document.createElement("input");
    inputfamillecarte_total.type = "text";
    inputfamillecarte_total.name = "famillecarte_total[]";
    inputfamillecarte_total.required = true;

    var labeltypecarte_code = document.createElement("label");
    labeltypecarte_code.textContent = "Code Type Carte :";
    var inputtypecarte_code = document.createElement("input");
    inputtypecarte_code.type = "text";
    inputtypecarte_code.name = "typecarte_code[]";
    inputtypecarte_code.required = true;

    var labeltypecarte_description = document.createElement("label");
    labeltypecarte_description.textContent = "Description Type Carte :";
    var inputtypecarte_description = document.createElement("input");
    inputtypecarte_description.type = "text";
    inputtypecarte_description.name = "typecarte_description[]";
    inputtypecarte_description.required = true;

    var labeltypecarte_nbcarte = document.createElement("label");
    labeltypecarte_nbcarte.textContent = "Nombre de Carte :";
    var inputtypecarte_nbcarte = document.createElement("input");
    inputtypecarte_nbcarte.type = "text";
    inputtypecarte_nbcarte.name = "typecarte_nbcarte[]";
    inputtypecarte_nbcarte.required = true;

    fieldset.appendChild(labelfamillecarte_code);
    fieldset.appendChild(inputfamillecarte_code);
    fieldset.appendChild(document.createElement("br"));
    fieldset.appendChild(labelfamillecarte_total);
    fieldset.appendChild(inputfamillecarte_total);
    fieldset.appendChild(document.createElement("br"));
    fieldset.appendChild(labeltypecarte_code);
    fieldset.appendChild(inputtypecarte_code);
    fieldset.appendChild(document.createElement("br"));
    fieldset.appendChild(labeltypecarte_description);
    fieldset.appendChild(inputtypecarte_description);
    fieldset.appendChild(document.createElement("br"));
    fieldset.appendChild(labeltypecarte_nbcarte);
    fieldset.appendChild(inputtypecarte_nbcarte);
    fieldset.appendChild(document.createElement("br"));

    var button = document.createElement('button');
        button.type = 'button';
        button.textContent = 'Supprimer';
        button.onclick = function() {
            detailsDiv.removeChild(fieldset);
        };

        fieldset.appendChild(button);

    detailsDiv.appendChild(fieldset);

    numData++;
}

</script>
</body>
</html>
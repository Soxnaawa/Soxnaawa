<!DOCTYPE html>
<html>
<head>
<title>Fraude Cheque Carte</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<!-- Formulaire pour déclarer les réclamations de chèques et de cartes -->
<form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
<legend><h2>Fraude de Chèque et de Carte</h2></legend>
<fieldset>
<legend><h2>Fraude</h2></legend>
<label for="debutperiode">Date de début</label><br>
<input type="date" id="debutperiode" name="debutperiode" required><br>
<label for="finperiode">Date de fin</label><br>
<input type="date" id="finperiode" name="finperiode" required><br>
</fieldset>
<fieldset>
<legend><h3>Détails de Fraude Chèques</h3></legend>
<div id="details_cheque">
<!-- Les champs pour les détails des réclamations de chèques seront générés ici par JavaScript -->
</div>
<button type="button" onclick="ajouterFraudeCheque()">Ajouter fraude Chèque</button>
</fieldset>
<fieldset>
<legend><h3>Détails des Fraudes de Carte</h3></legend>
<div id="details_carte">
<!-- Les champs pour les détails des réclamations de cartes seront générés ici par JavaScript -->
</div>
<button type="button" onclick="ajouterFraudeCarte()">Ajouter Fraude Carte</button>
</fieldset>
<input type="submit" value="Soumettre">
</form>
<script>
function ajouterFraudeCheque() {
var detailsDiv = document.getElementById('details_cheque');
var numfraude = detailsDiv.getElementsByTagName('fieldset').length + 1;

var fieldset = document.createElement('fieldset');
var legend = document.createElement('legend');
legend.textContent = 'Fraude de Chèque ' + numfraude;
fieldset.appendChild(legend);

// Génération automatique du code du type de chèque
var typeChequeCode = 'FRACHEQUE_' + numfraude;

var labels = ['Code Type Chèque', 'Date Fraude', 'Libelle Fraude', 'Mesures Correctives', 'Mode Operatoire', 'Nombre Fraude', 'Valeur CFA'];
var names = ['typechequecode[]', 'datefraude_cheque[]', 'libellefraude_cheque[]', 'mesurescorrectives_cheque[]', 'modeoperatoire_cheque[]', 'nombrefraude_cheque[]', 'valeur_cfa_cheque[]'];
var types = ['text', 'date', 'textarea', 'textarea', 'text', 'number', 'number'];

for (let i = 0; i < labels.length; i++) {
var label = document.createElement('label');
label.textContent = labels[i];
var input;
if (types[i] === 'textarea') {
input = document.createElement('textarea');
} else {
input = document.createElement('input');
input.type = types[i];
}
input.name = names[i];
if (names[i] === 'typechequecode[]') {
input.value = typeChequeCode;
input.readOnly = false;
}

fieldset.appendChild(label);
fieldset.appendChild(input);
fieldset.appendChild(document.createElement('br'));
}

// Ajouter le bouton de retour
var button = document.createElement('button');
button.type = 'button';
button.textContent = 'Supprimer';
button.onclick = function() {
detailsDiv.removeChild(fieldset);
};

fieldset.appendChild(button);
detailsDiv.appendChild(fieldset);
}

function ajouterFraudeCarte() {
var detailsDiv = document.getElementById('details_carte');
var numfraude = detailsDiv.getElementsByTagName('fieldset').length + 1;

var fieldset = document.createElement('fieldset');
var legend = document.createElement('legend');
legend.textContent = 'Fraude de Carte ' + numfraude;
fieldset.appendChild(legend);

// Génération automatique du code du type de carte
var typeCarteCode = 'FRCARTE_' + numfraude;

var labels = ['Code Type Carte', 'Date Fraude', 'Libelle Fraude', 'Mesures Correctives', 'Mode Operatoire', 'Nombre Fraude', 'Valeur CFA'];
var names = ['typecartecode[]', 'datefraude_carte[]', 'libellefraude_carte[]', 'mesurescorrectives_carte[]', 'modeoperatoire_carte[]', 'nombrefraude_carte[]', 'valeur_cfa_carte[]'];
var types = ['text', 'date', 'textarea', 'textarea', 'text', 'number', 'number'];

for (let i = 0; i < labels.length; i++) {
var label = document.createElement('label');
label.textContent = labels[i];
var input;
if (types[i] === 'textarea') {
input = document.createElement('textarea');
} else {
input = document.createElement('input');
input.type = types[i];
}
input.name = names[i];
if (names[i] === 'typecartecode[]') {
input.value = typeCarteCode;
input.readOnly = false;
}

fieldset.appendChild(label);
fieldset.appendChild(input);
fieldset.appendChild(document.createElement('br'));
}

// Ajouter le bouton de retour
var button = document.createElement('button');
button.type = 'button';
button.textContent = 'Supprimer';
button.onclick = function() {
detailsDiv.removeChild(fieldset);
};

fieldset.appendChild(button);
detailsDiv.appendChild(fieldset);
}
</script>


<?php
// Paramètres de connexion à la base de données
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "users";
// Connexion à la base de données
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérifier la connexion
if ($conn->connect_error) {
die("Échec de la connexion : " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
// Récupérer les données soumises du formulaire
$debutperiode = $_POST['debutperiode'];
$finperiode = $_POST['finperiode'];

$typechequecode = isset($_POST['typechequecode']) ? $_POST['typechequecode'] : [];
$datefraude_cheque = isset($_POST['datefraude_cheque']) ? $_POST['datefraude_cheque'] : [];
$libellefraude_cheque = isset($_POST['libellefraude_cheque']) ? $_POST['libellefraude_cheque'] : [];
$mesurescorrectives_cheque = isset($_POST['mesurescorrectives_cheque']) ? $_POST['mesurescorrectives_cheque'] : [];
$modeoperatoire_cheque = isset($_POST['modeoperatoire_cheque']) ? $_POST['modeoperatoire_cheque'] : [];
$nombrefraude_cheque = isset($_POST['nombrefraude_cheque']) ? $_POST['nombrefraude_cheque'] : [];
$valeur_cfa_cheque = isset($_POST['valeur_cfa_cheque']) ? $_POST['valeur_cfa_cheque'] : [];

$typecartecode = isset($_POST['typecartecode']) ? $_POST['typecartecode'] : [];
$datefraude_carte = isset($_POST['datefraude_carte']) ? $_POST['datefraude_carte'] : [];
$libellefraude_carte = isset($_POST['libellefraude_carte']) ? $_POST['libellefraude_carte'] : [];
$mesurescorrectives_carte = isset($_POST['mesurescorrectives_carte']) ? $_POST['mesurescorrectives_carte'] : [];
$modeoperatoire_carte = isset($_POST['modeoperatoire_carte']) ? $_POST['modeoperatoire_carte'] : [];
$nombrefraude_carte = isset($_POST['nombrefraude_carte']) ? $_POST['nombrefraude_carte'] : [];
$valeur_cfa_carte = isset($_POST['valeur_cfa_carte']) ? $_POST['valeur_cfa_carte'] : [];

// Initialiser les totaux
$total_nombre_fraude_cheque = array_sum($nombrefraude_cheque);
$total_valeur_cfa_cheque = array_sum($valeur_cfa_cheque);
$total_nombre_fraude_carte = array_sum($nombrefraude_carte);
$total_valeur_cfa_carte = array_sum($valeur_cfa_carte);

$totalfraude = $total_nombre_fraude_cheque + $total_nombre_fraude_carte;
$valeurtotal = $total_valeur_cfa_cheque + $total_valeur_cfa_carte;

echo "<div id='donneesSoumises'>";
echo '<h2>Données Soumises</h2>';
echo '<h3>Date de début : ' . $debutperiode . '</h3>';
echo ' <h3>Date de fin ' . $finperiode . '</h3>';
echo '<p><strong>Total Nombre de Fraudes (Chèques et Cartes):</strong> ' . $totalfraude . '</p>';
echo '<p><strong>Total Valeur en CFA (Chèques et Cartes):</strong> ' . $valeurtotal . '</p>';

echo '<h3>Détails des Fraudes de Chèques:</h3>';
for ($i = 0; $i < count($typechequecode); $i++) {
echo '<p><strong>Fraude Chèque ' . ($i + 1) . ':</strong></p>';
echo '<p>Code Type: ' . $typechequecode[$i] . '</p>';
echo '<p>Date Fraude: ' . $datefraude_cheque[$i] . '</p>';
echo '<p>Libellé Fraude: ' . $libellefraude_cheque[$i] . '</p>';
echo '<p>Mesures Correctives: ' . $mesurescorrectives_cheque[$i] . '</p>';
echo '<p>Mode Opératoire: ' . $modeoperatoire_cheque[$i] . '</p>';
echo '<p>Nombre Fraude: ' . $nombrefraude_cheque[$i] . '</p>';
echo '<p>Valeur CFA: ' . $valeur_cfa_cheque[$i] . '</p>';
}


for ($i = 0; $i < count($typecartecode); $i++) {
echo '<h3>Détails des Fraudes de Cartes:</h3>';
echo '<p><strong>Fraude Carte ' . ($i + 1) . ':</strong></p>';
echo '<p>Code Type: ' . $typecartecode[$i] . '</p>';
echo '<p>Date Fraude: ' . $datefraude_carte[$i] . '</p>';
echo '<p>Libellé Fraude: ' . $libellefraude_carte[$i] . '</p>';
echo '<p>Mesures Correctives: ' . $mesurescorrectives_carte[$i] . '</p>';
echo '<p>Mode Opératoire: ' . $modeoperatoire_carte[$i] . '</p>';
echo '<p>Nombre Fraude: ' . $nombrefraude_carte[$i] . '</p>';
echo '<p>Valeur CFA: ' . $valeur_cfa_carte[$i] . '</p>';
}
echo "</div>";

// Insérer les données dans la table fraude_cheque
if (!empty($typechequecode)) {
$sql = "INSERT INTO fraude_cheque (debutperiode, finperiode, typechequecode, datefraude, libellefraude, mesurescorrectives, modeoperatoire, nombrefraude, valeur_cfa)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssssii", $debutperiode, $finperiode, $typechequecode, $datefraude_cheque, $libellefraude_cheque, $mesurescorrectives_cheque, $modeoperatoire_cheque, $nombrefraude_cheque, $valeur_cfa_cheque);

for ($i = 0; $i < count($typechequecode); $i++) {
$stmt->execute([$debutperiode, $finperiode, $typechequecode[$i], $datefraude_cheque[$i], $libellefraude_cheque[$i], $mesurescorrectives_cheque[$i], $modeoperatoire_cheque[$i], $nombrefraude_cheque[$i], $valeur_cfa_cheque[$i]]);
}
}

// Insérer les données dans la table fraude_carte
if (!empty($typecartecode)) {
$sql = "INSERT INTO fraude_carte (debutperiode, finperiode, typecartecode, datefraude, libellefraude, mesurescorrectives, modeoperatoire, nombrefraude, valeur_cfa)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssssii", $debutperiode, $finperiode, $typecartecode, $datefraude_carte, $libellefraude_carte, $mesurescorrectives_carte, $modeoperatoire_carte, $nombrefraude_carte, $valeur_cfa_carte);

for ($i = 0; $i < count($typecartecode); $i++) {
$stmt->execute([$debutperiode, $finperiode, $typecartecode[$i], $datefraude_carte[$i], $libellefraude_carte[$i], $mesurescorrectives_carte[$i], $modeoperatoire_carte[$i], $nombrefraude_carte[$i], $valeur_cfa_carte[$i]]);
}
}



$stmt->close();

// Générer le fichier XML
$xml = new DOMDocument('1.0', 'UTF-8');
$xml->formatOutput = true;

// Élément racine <fraudechequecarte>
$fraudechequecarte = $xml->createElement('fraudechequecarte');
$xml->appendChild($fraudechequecarte);

// Élément <fraude>
$fraude = $xml->createElement('fraude');
$fraudechequecarte->appendChild($fraude);

// Ajouter les éléments <debutperiode> et <finperiode>
$fraude->appendChild($xml->createElement('debutperiode', $debutperiode));
$fraude->appendChild($xml->createElement('finperiode', $finperiode));

// Ajouter les éléments <totalfraude> et <totalvaleurcfa>
$fraude->appendChild($xml->createElement('totalfraude', $totalfraude));
$fraude->appendChild($xml->createElement('totalvaleurcfa', $valeurtotal));

// Élément <details>
$details = $xml->createElement('details');
$fraudechequecarte->appendChild($details);

// Ajouter les détails des fraudes de chèques
for ($i = 0; $i < count($typechequecode); $i++) {
$data = $xml->createElement('data');
$data->setAttribute('type', 'CHEQUE');
$data->setAttribute('code', $typechequecode[$i]);

$data->appendChild($xml->createElement('datefraude', $datefraude_cheque[$i]));
$data->appendChild($xml->createElement('libellefraude', '![CDATA[' . $libellefraude_cheque[$i] . ']]'));
$data->appendChild($xml->createElement('mesurescorrectives', '![CDATA[' . $mesurescorrectives_cheque[$i] . ']]'));
$data->appendChild($xml->createElement('modeoperatoire', '![CDATA[' . $modeoperatoire_cheque[$i] . ']]'));
$data->appendChild($xml->createElement('nbfraude', $nombrefraude_cheque[$i]));
$data->appendChild($xml->createElement('valeurcfa', $valeur_cfa_cheque[$i]));

$details->appendChild($data);
}

// Ajouter les détails des fraudes de cartes
for ($i = 0; $i < count($typecartecode); $i++) {
$data = $xml->createElement('data');
$data->setAttribute('type', 'CARTE');
$data->setAttribute('code', $typecartecode[$i]);

$data->appendChild($xml->createElement('datefraude', $datefraude_carte[$i]));
$data->appendChild($xml->createElement('libellefraude', '![CDATA[' . $libellefraude_carte[$i] . ']]'));
$data->appendChild($xml->createElement('mesurescorrectives', '![CDATA[' . $mesurescorrectives_carte[$i] . ']]'));
$data->appendChild($xml->createElement('modeoperatoire', '![CDATA[' . $modeoperatoire_carte[$i] . ']]'));
$data->appendChild($xml->createElement('nbfraude', $nombrefraude_carte[$i]));
$data->appendChild($xml->createElement('valeurcfa', $valeur_cfa_carte[$i]));

$details->appendChild($data);
}
// Créer la période de référence
$refperiode = date('Ym', strtotime($debutperiode)) . '-' . date('Ym', strtotime($finperiode));


$codeEmetteur = "CODEETABLISSEMENT"; // Remplacez par la valeur appropriée
$refPeriode = date("d_m_Y");
$frequence = "S"; // Exemple, remplacez par la valeur appropriée
$codeBranche = "FRAUDECHEQUECARTE"; // Remplacez par la valeur appropriée

// Déterminer la version du fichier
$version = 1;
$baseFilename = "EME_{$codeEmetteur}_{$refPeriode}_{$frequence}_{$codeBranche}_";
$directory = __DIR__; // Répertoire actuel
$files = glob($directory . "/" . $baseFilename . "*.xml");

if ($files) {
// Extraire les numéros de version des fichiers existants et déterminer le prochain numéro de version
$maxVersion = 0;
foreach ($files as $file) {
if (preg_match('/_(\d+)_XML\.XML$/', $file, $matches)) {
$fileVersion = (int)$matches[1];
if ($fileVersion > $maxVersion) {
$maxVersion = $fileVersion;
}
}
}
$version = $maxVersion + 1;
}

$xml_filename = "{$baseFilename}{$version}_XML.XML";
$xml->save($xml_filename);

// Afficher le message de succès avec un lien vers le fichier XML
echo "<div style='font-family: Arial, sans-serif; text-align: center; margin-top: 10px; padding: 30px;'>";
echo "<h2 style='color: #008a50;'>Les informations ont été enregistrées.</h2>";
echo "<a href='$xml_filename' style='text-decoration: none; color: #008a50;'>Télécharger le fichier XML</a>";
echo "</div>";

}

// Fermer la connexion
$conn->close();
?>
</body>
</html>
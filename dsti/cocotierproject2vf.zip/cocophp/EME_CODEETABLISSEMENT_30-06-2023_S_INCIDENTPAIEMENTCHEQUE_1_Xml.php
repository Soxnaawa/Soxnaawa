<!DOCTYPE html>
<html>
<head>
    <title>Incident Paiement Chéque</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <fieldset>
        <legend><h2>Incident Paiement Chéque</h2></legend>
        <label for="debutperiode">Début de période:</label><br>
        <input type="date" id="debutperiode" name="debutperiode" required><br>
        <label for="finperiode">Fin de période:</label><br>
        <input type="date" id="finperiode" name="finperiode" required><br>
        <label for="totalnombre">Total nombre:</label><br>
        <input type="number" id="totalnombre" name="totalnombre" required><br>
        <label for="totalvaleurcfa">total Valeur CFA:</label><br>
        <input type="number" id="totalvaleurcfa" name="totalvaleurcfa" required><br>
    </fieldset>

    <div id="details"></div>

    <button type="button" onclick="ajouterdetailscheque()">Ajouter details paiement Cheque</button>
   
    <input type="submit" value="Soumettre">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connexion à la base de données
    $servername = "localhost"; // À adapter selon votre configuration
    $username = "root"; // À adapter selon votre configuration
    $password = ""; // À adapter selon votre configuration
    $dbname = "users"; // À adapter selon votre configuration

    // Création de la connexion
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérification de la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Préparation de la requête d'insertion
    $stmt = $conn->prepare("INSERT INTO incidentpaiementcheque (debutperiode, finperiode, totalnombre, totalvaleurcfa, typenomenclature_code, description, nbcheque,valeurcfa) VALUES (?, ?, ?, ?, ?, ?, ?,?)");

    if (!$stmt) {
        die("Preparation failed: " . $conn->error);
    }

    $debutperiode = $_POST['debutperiode'];
    $finperiode = $_POST['finperiode'];
    $totalnombre = $_POST['totalnombre'];
    $totalvaleurcfa = $_POST['totalvaleurcfa'];

    echo "<div id='donneesSoumises'>";
    echo "<h2>Données soumises :</h2>";
    echo "<fieldset>";
    echo "<p>Début de période : " . htmlspecialchars($debutperiode) . "</p>";
    echo "<p>Fin de période : " . htmlspecialchars($finperiode) . "</p>";
    echo "<p>Total nombre : " . htmlspecialchars($totalnombre) . "</p>";
    echo "<p>total Valeur CFA : " . htmlspecialchars($totalvaleurcfa) . "</p>";

    // Création de l'objet XML
    $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><incidentpaiementcheque/>');
    $incident = $xml->addChild('incident');
    $incident->addChild('debutperiode', $debutperiode);
    $incident->addChild('finperiode', $finperiode);
    $incident->addChild('totalnombre', $totalnombre);
    $incident->addChild('totalvaleurcfa', $totalvaleurcfa);

    $details = $xml->addChild('details');

   // $stmt->bind_param("ssiiisssssssssss", $debutperiode, $finperiode, $totalnombre, $totalvaleurcfa, $typenomenclature_code, $description, $nbcheque, $risque, $nboccurrence, $descriptiondetaillee, $mesurescorrectives, $impactfinancier, $statutincident, $datecloture, $infoscomplementaires);
   $stmt->bind_param("ssiissii", $debutperiode, $finperiode, $totalnombre, $totalvaleurcfa, $typenomenclature_code, $description, $nbcheque,$valeurcfa);
    
    $stmt->execute();

    if (!empty($_POST['typenomenclature_code'])) {
        echo "<h3>Details :</h3>";
        echo "<ul>";
        foreach ($_POST['typenomenclature_code'] as $key => $value) {
            $typenomenclature_code = !empty($_POST['typenomenclature_code'][$key]) ? $_POST['typenomenclature_code'][$key] : null;
            $description = !empty($_POST['description'][$key]) ? $_POST['description'][$key] : null;
            $nbcheque = !empty($_POST['nbcheque'][$key]) ? $_POST['nbcheque'][$key] : null;
            $valeurcfa = !empty($_POST['valeurcfa'][$key]) ? $_POST['valeurcfa'][$key] : null;

            echo "<li>Données paiement chéque " . ($key + 1) . "</li>";
            echo "<ul>";
            echo "<li>Code Type nomenclature : " . htmlspecialchars($typenomenclature_code) . "</li>";
            echo "<li>Description : " . htmlspecialchars($description) . "</li>";
            echo "<li>Nombre de Chéques : " . htmlspecialchars($nbcheque) . "</li>";
            echo "<li>Valeur en CFA : " . htmlspecialchars($valeurcfa) . "</li>";

            // Ajout des détails dans le fichier XML
            $typenomenclature = $details->addChild('typenomenclature');
            $typenomenclature->addAttribute('code', $typenomenclature_code);
            $typenomenclature->addChild('description', $description);
            $typenomenclature->addChild('nbcheque', $nbcheque);
            $typenomenclature->addChild('valeurcfa', $valeurcfa);
            // Insertion des détails dans la base de données
            //$stmt->bind_param("ssissssssssisss", $debutperiode, $finperiode, $totalnombre, $totalvaleurcfa, $typenomenclature_code, $description, $nbcheque, $risque, $nboccurrence, $descriptiondetaillee, $mesurescorrectives, $impactfinancier, $statutincident, $datecloture, $infoscomplementaires);
            $stmt->execute();
        }
        echo "</ul>";
    }
    echo "</fieldset>";
    echo "</div>";

    // Fermeture de la requête et de la connexion
    $stmt->close();
    $conn->close();

    // Enregistrement du fichier XML
    $dom = new DOMDocument('1.0');
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    $dom->loadXML($xml->asXML());
    // Nom du fichier XML
    $xml_filename = "EME_CODEETABLISSEMENT_" . date("d_m_Y") . "_S_INCIDENTPAIEMENTCHEQUE_1_XML.xml";
    $dom->save($xml_filename);
}
?>

<script>
var numData = 1;

function ajouterdetailscheque() {
    var detailsDiv = document.getElementById("details");

    var fieldset = document.createElement("fieldset");
    var legend = document.createElement("legend");
    legend.textContent = "Details paiement cheque " + numData;
    fieldset.appendChild(legend);

    var labeltypenomenclature_code = document.createElement("label");
    labeltypenomenclature_code.setAttribute("for", "typenomenclature_code_" + numData);
    labeltypenomenclature_code.textContent = "code type nomenclature:";
    fieldset.appendChild(labeltypenomenclature_code);
    var inputtypenomenclature_code = document.createElement("input");
    inputtypenomenclature_code.type = "text";
    inputtypenomenclature_code.id = "typenomenclature_code_" + numData;
    inputtypenomenclature_code.name = "typenomenclature_code[]";
    fieldset.appendChild(inputtypenomenclature_code);
    fieldset.appendChild(document.createElement("br"));

    var labeldescription = document.createElement("label");
    labeldescription.setAttribute("for", "description_" + numData);
    labeldescription.textContent = "Description:";
    fieldset.appendChild(labeldescription);
    var inputdescription = document.createElement("input");
    inputdescription.type = "text";
    inputdescription.id = "description_" + numData;
    inputdescription.name = "description[]";
    fieldset.appendChild(inputdescription);
    fieldset.appendChild(document.createElement("br"));

    var labelnbcheque = document.createElement("label");
    labelnbcheque.setAttribute("for", "nbcheque_" + numData);
    labelnbcheque.textContent = "Nombre de Cheques:";
    fieldset.appendChild(labelnbcheque);
    var inputnbcheque = document.createElement("input");
    inputnbcheque.type = "number";
    inputnbcheque.id = "nbcheque_" + numData;
    inputnbcheque.name = "nbcheque[]";
    fieldset.appendChild(inputnbcheque);
    fieldset.appendChild(document.createElement("br"));

    var labelvaleurcfa = document.createElement("label");
    labelvaleurcfa.setAttribute("for", "valeurcfa_" + numData);
    labelvaleurcfa.textContent = "Valeur en CFA:";
    fieldset.appendChild(labelvaleurcfa);
    var inputvaleurcfa = document.createElement("input");
    inputvaleurcfa.type = "number";
    inputvaleurcfa.id = "valeurcfa_" + numData;
    inputvaleurcfa.name = "valeurcfa[]";
    fieldset.appendChild(inputvaleurcfa);
    fieldset.appendChild(document.createElement("br"));
    var button = document.createElement('button');
        button.type = 'button';
        button.textContent = 'Supprimer';
        button.onclick = function() {
            detailsDiv.removeChild(fieldset);
        };

        fieldset.appendChild(button);
    

    detailsDiv.appendChild(fieldset);

    numData++;
}

</script>
</body>
</html>
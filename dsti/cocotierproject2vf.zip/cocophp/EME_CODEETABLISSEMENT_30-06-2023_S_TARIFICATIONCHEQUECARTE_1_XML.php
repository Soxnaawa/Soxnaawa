<!DOCTYPE html>
<html>
<head>
    <title>Tarif Cheque Carte</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <fieldset>
        <legend><h2>Tarif Cheque Carte</h2></legend>
        <label for="debutperiode">Début de période:</label><br>
        <input type="date" id="debutperiode" name="debutperiode" required><br>
        <label for="finperiode">Fin de période:</label><br>
        <input type="date" id="finperiode" name="finperiode" required><br>
        
    </fieldset>

    <div id="details"></div>

    <button type="button" onclick="ajouterdetailscarte()">Ajouter details tarif carte</button>
    <!--<button type="button" onclick="ajouterdetailscheque()">Ajouter details cheque et carte</button> !-->
    <button type="button" onclick="ajouterdetailscheque()">Ajouter details tarif cheque </button>
   
    <input type="submit" value="Soumettre">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connexion à la base de données
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "users";

    // Création de la connexion
    $conn = new mysqli($servername, $username, $password, $dbname);
    $conn1 = new mysqli($servername, $username, $password, $dbname);

    // Vérification de la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    if ($conn1->connect_error) {
        die("Connection failed: " . $conn1->connect_error);
    }

    // Préparation de la requête d'insertion
    $stmt = $conn->prepare("INSERT INTO tarificationcheque (debutperiode, finperiode, typeservice_code, coutminimum) VALUES (?, ?, ?, ?)");
    $stmt1 = $conn1->prepare("INSERT INTO tarificationcarte (debutperiode, finperiode, typeservicecarte_code, coutminimum) VALUES (?, ?, ?, ?)");
    if (!$stmt) {
        die("Preparation failed: " . $conn->error);
    }
    if (!$stmt1) {
        die("Preparation failed: " . $conn1->error);
    }

    $debutperiode = $_POST['debutperiode'];
    $finperiode = $_POST['finperiode'];

    echo "<div id='donneesSoumises'>";
    echo "<h2>Données soumises :</h2>";
    echo "<fieldset>";
    echo "<p>Début de période : " . htmlspecialchars($debutperiode) . "</p>";
    echo "<p>Fin de période : " . htmlspecialchars($finperiode) . "</p>";

    // Création de l'objet XML
    $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><tarificationchequecarte/>');
    $tarification = $xml->addChild('tarification');
    $tarification->addChild('debutperiode', $debutperiode);
    $tarification->addChild('finperiode', $finperiode);

    $details = $xml->addChild('details');

    $stmt->bind_param("sssi", $debutperiode, $finperiode, $typeservice_code, $coutminimum);
    $stmt1->bind_param("sssi", $debutperiode, $finperiode, $typeservicecarte_code, $coutminimum1);

    $stmt->execute();
    if (!empty($_POST['typeservicecarte_code'])) {
        echo "<h3>Details :</h3>";
         echo "<ul>";
         foreach ($_POST['typeservicecarte_code'] as $key => $value) {
             $typeservicecarte_code = !empty($_POST['typeservicecarte_code'][$key]) ? $_POST['typeservicecarte_code'][$key] : null;
             $coutminimum1 = !empty($_POST['coutminimum'][$key]) ? $_POST['coutminimum'][$key] : null;
 
             echo "<li>Données tarif carte " . ($key + 1) . "</li>";
             echo "<ul>";
             echo "<li>Code Type service : " . htmlspecialchars($typeservicecarte_code) . "</li>";
             echo "<li>Cout Minimum: " . htmlspecialchars($coutminimum1) . "</li>";
 
             // Ajout des détails dans le fichier XML
             $carte = $details->addChild('cartes');
             $typeservice = $carte->addChild('typeservice');
             $typeservice->addAttribute('code', $typeservicecarte_code);
             $typeservice->addChild('coutminimum', $coutminimum1);
 
             // Insertion des détails dans la base de données
             $stmt1->execute();
         }
         echo "</ul>";
     }
    if (!empty($_POST['typeservice_code'])) {
       
        echo "<ul>";
        foreach ($_POST['typeservice_code'] as $key => $value) {
            $typeservice_code = !empty($_POST['typeservice_code'][$key]) ? $_POST['typeservice_code'][$key] : null;
            $coutminimum = !empty($_POST['coutminimum'][$key]) ? $_POST['coutminimum'][$key] : null;

            echo "<li>Données tarif cheque " . ($key + 1) . "</li>";
            echo "<ul>";
            echo "<li>Code Type service : " . htmlspecialchars($typeservice_code) . "</li>";
            echo "<li>Cout Minimum: " . htmlspecialchars($coutminimum) . "</li>";

            // Ajout des détails dans le fichier XML
            $cheque = $details->addChild('cheques');
            $typeservice = $cheque->addChild('typeservice');
            $typeservice->addAttribute('code', $typeservice_code);
            $typeservice->addChild('coutminimum', $coutminimum);

            // Insertion des détails dans la base de données
            $stmt->execute();
        }
        echo "</ul>";
    }
    
    echo "</fieldset>";
    echo "</div>";

    // Fermeture de la requête et de la connexion
    $stmt->close();
    $stmt1->close();
    $conn->close();
    $conn1->close();

    // Enregistrement du fichier XML
    $dom = new DOMDocument('1.0');
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    $dom->loadXML($xml->asXML());
    $xml_filename = "EME_CODEETABLISSEMENT_" . date("d_m_Y") . "_S_TARIFCHEQUECARTE_1_XML.xml";
    $dom->save($xml_filename);
}
?>

<script>
var numData = 1;
var numData1 = 1;

function ajouterdetailscarte() {
    var detailsDiv = document.getElementById("details");

    var fieldset = document.createElement("fieldset");
    var legend = document.createElement("legend");
    legend.textContent = "Details Tarification carte " + numData;
    fieldset.appendChild(legend);

    var labeltypeservicecarte_code = document.createElement("label");
    labeltypeservicecarte_code.setAttribute("for", "typeservicecarte_code_" + numData);
    labeltypeservicecarte_code.textContent = "Code Type Service CARTE:";
    fieldset.appendChild(labeltypeservicecarte_code);
    var inputtypeservicecarte_code = document.createElement("input");
    inputtypeservicecarte_code.type = "text";
    inputtypeservicecarte_code.id = "typeservicecarte_code_" + numData;
    inputtypeservicecarte_code.name = "typeservicecarte_code[]";
    fieldset.appendChild(inputtypeservicecarte_code);
    fieldset.appendChild(document.createElement("br"));

    

   

    var labelcoutminimum = document.createElement("label");
    labelcoutminimum.setAttribute("for", "coutminimum_" + numData);
    labelcoutminimum.textContent = "Cout Minimum:";
    fieldset.appendChild(labelcoutminimum);
    var inputcoutminimum = document.createElement("input");
    inputcoutminimum.type = "number";
    inputcoutminimum.id = "coutminimum_" + numData;
    inputcoutminimum.name = "coutminimum[]";
    fieldset.appendChild(inputcoutminimum);
    fieldset.appendChild(document.createElement("br"));

    var button = document.createElement('button');
        button.type = 'button';
        button.textContent = 'Supprimer';
        button.onclick = function() {
            detailsDiv.removeChild(fieldset);
        };

        fieldset.appendChild(button);

    detailsDiv.appendChild(fieldset);

    numData++;
}


function ajouterdetailscheque() {
    var detailsDiv = document.getElementById("details");

    var fieldset = document.createElement("fieldset");
    var legend = document.createElement("legend");
    legend.textContent = "Details tarification cheque " + numData1;
    fieldset.appendChild(legend);

    var labeltypeservice_code = document.createElement("label");
    labeltypeservice_code.setAttribute("for", "typeservice_code_" + numData1);
    labeltypeservice_code.textContent = "Code Type Service:";
    fieldset.appendChild(labeltypeservice_code);
    var inputtypeservice_code = document.createElement("input");
    inputtypeservice_code.type = "text";
    inputtypeservice_code.id = "typeservice_code_" + numData1;
    inputtypeservice_code.name = "typeservice_code[]";
    fieldset.appendChild(inputtypeservice_code);
    fieldset.appendChild(document.createElement("br"));

    

   

    var labelcoutminimum = document.createElement("label");
    labelcoutminimum.setAttribute("for", "coutminimum_" + numData1);
    labelcoutminimum.textContent = "Cout Minimum:";
    fieldset.appendChild(labelcoutminimum);
    var inputcoutminimum = document.createElement("input");
    inputcoutminimum.type = "number";
    inputcoutminimum.id = "coutminimum_" + numData1;
    inputcoutminimum.name = "coutminimum[]";
    fieldset.appendChild(inputcoutminimum);
    fieldset.appendChild(document.createElement("br"));

    var button = document.createElement('button');
        button.type = 'button';
        button.textContent = 'Supprimer';
        button.onclick = function() {
            detailsDiv.removeChild(fieldset);
        };

        fieldset.appendChild(button);
    

    detailsDiv.appendChild(fieldset);

    numData1++;
}


</script>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
    <title>Déclaration des Risques STRA</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <!-- Formulaire pour déclarer les risques -->
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
    <legend><h2>Déclaration des Risques STRA</h2></legend>
        <fieldset>
            <legend><h2>Déclaration </h2></legend>
            <label for="debutperiode">Début de période</label><br>
            <input type="date" id="debutperiode" name="debutperiode" required><br>
            <label for="finperiode">Fin de période</label><br>
            <input type="date" id="finperiode" name="finperiode" required><br>
            <label for="nbrisque">Nombre de risques</label><br>
            <input type="number" id="nbrisque" name="nbrisque" required><br>
        </fieldset>
        <fieldset>
            <legend><h3>Détails des Risques STRA</h3></legend>
            <div id="details">
                <!-- Les champs pour les détails des risques seront générés ici par JavaScript -->
            </div>
            <button type="button" onclick="ajouterRisque()">Ajouter Risque</button>
           
        </fieldset>
        <input type="submit" value="Soumettre">
    </form>

    <!-- Script pour ajouter dynamiquement des champs de risque -->
    <script>
    function ajouterRisque() {
        var detailsDiv = document.getElementById('details');
        var numRisque = detailsDiv.getElementsByTagName('fieldset').length + 1;

        var fieldset = document.createElement('fieldset');
        var legend = document.createElement('legend');
        legend.textContent = 'Risque STRA ' + numRisque;
        fieldset.appendChild(legend);

        var labelTypeRisqueCode = document.createElement('label');
        labelTypeRisqueCode.textContent = 'Type Risque Code';
        var inputTypeRisqueCode = document.createElement('input');
        inputTypeRisqueCode.type = 'text';
        inputTypeRisqueCode.name = 'typerisquecode[]';
        inputTypeRisqueCode.required = true;

        var labelRisque = document.createElement('label');
        labelRisque.textContent = 'Risque';
        var inputRisque = document.createElement('textarea');
        inputRisque.name = 'Risque[]';
        inputRisque.required = true;

        var labelMecanismeMaitrise = document.createElement('label');
        labelMecanismeMaitrise.textContent = 'Mecanisme Maitrise';
        var inputMecanismeMaitrise = document.createElement('textarea');
        inputMecanismeMaitrise.name = 'Mecanismemaitrise[]';
        inputMecanismeMaitrise.required = true;

        fieldset.appendChild(labelTypeRisqueCode);
        fieldset.appendChild(inputTypeRisqueCode);
        fieldset.appendChild(document.createElement('br'));
        fieldset.appendChild(labelRisque);
        fieldset.appendChild(inputRisque);
        fieldset.appendChild(document.createElement('br'));
        fieldset.appendChild(labelMecanismeMaitrise);
        fieldset.appendChild(inputMecanismeMaitrise);
        fieldset.appendChild(document.createElement('br'));

        // Ajouter le bouton de retour
        var button = document.createElement('button');
        button.type = 'button';
        button.textContent = 'Supprimer';
        button.onclick = function() {
            detailsDiv.removeChild(fieldset);
        };

        fieldset.appendChild(button);
        detailsDiv.appendChild(fieldset);
    }
</script>

    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "users";

    // Connexion à la base de données
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("Échec de la connexion : " . $conn->connect_error);
    }

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données soumises du formulaire
    $debutperiode = $_POST['debutperiode'];
    $finperiode = $_POST['finperiode'];
    $nbrisque = $_POST['nbrisque'];
    $typerisquecode = $_POST['typerisquecode'];
    $Risque = $_POST['Risque'];
    $Mecanismemaitrise = $_POST['Mecanismemaitrise'];

    // Afficher les données soumises
    echo "<div id='donneesSoumises'>";
    echo "<h2>Données Soumises :</h2>";
    echo "<p>Début de période : " . htmlspecialchars($debutperiode) . "</p>";
    echo "<p>Fin de période : " . htmlspecialchars($finperiode) . "</p>";
    echo "<h3>Détails des Risques STRA</h3>";

    $stmt = $conn->prepare("INSERT INTO risquestra (debutperiode, finperiode, typerisquecode,  risques , mecanismemaitrise ) VALUES (?, ?, ?, ?, ?)");

    foreach ($Risque as $key => $risques) {
        echo "<p>Risque " . ($key + 1) . " :</p>";
        echo "<p>Type Risque Code : " . htmlspecialchars($typerisquecode[$key]) . "</p>";
        echo "<p>Risque : " . htmlspecialchars($risques) . "</p>";
        echo "<p>Mecanisme Maitrise : " . htmlspecialchars($Mecanismemaitrise[$key]) . "</p>";
    
         // Lier les paramètres et exécuter la requête
         $stmt->bind_param("ddsss", $debutperiode, $finperiode, $typerisquecode[$key], $risques , $Mecanismemaitrise[$key]);
         $stmt->execute();
    }
    echo "</div>";

    $stmt->close();

    // Générer le fichier XML
    $xml = new DOMDocument('1.0', 'UTF-8');
    $xml->formatOutput = true;

    // Élément racine <risquestra>
    $risquestra = $xml->createElement('risquestra');
    $xml->appendChild($risquestra);

    // Élément <declaration>
    $declaration = $xml->createElement('declaration');
    $risquestra->appendChild($declaration);

    $declaration->appendChild($xml->createElement('debutperiode', $debutperiode));
    $declaration->appendChild($xml->createElement('finperiode', $finperiode));
    $declaration->appendChild($xml->createElement('nb_risque', $nbrisque));

    // Élément <details>
    $detailsElem = $xml->createElement('details');
    $risquestra->appendChild($detailsElem);

    // Itérer sur les risques
    foreach ($typerisquecode as $key => $code) {
        $typeRisqueElem = $xml->createElement('type_risque');
        $typeRisqueElem->setAttribute('code', htmlspecialchars($code));

        $risqueElem = $xml->createElement('risque');
        $risqueElem->appendChild($xml->createCDATASection($Risque[$key]));
        $typeRisqueElem->appendChild($risqueElem);

        $mecanismeElem = $xml->createElement('mecanisme_maitrise');
        $mecanismeElem->appendChild($xml->createCDATASection($Mecanismemaitrise[$key]));
        $typeRisqueElem->appendChild($mecanismeElem);

        $detailsElem->appendChild($typeRisqueElem);
    }

    // Construire le nom de fichier selon la nomenclature
    $codeEmetteur = "CODEETABLISSEMENT"; // Remplacez par la valeur appropriée
    $refPeriode = date("d_m_Y");
    $frequence = "T"; // Exemple, remplacez par la valeur appropriée
    $codeBranche = "RISQUESTRA"; // Remplacez par la valeur appropriée

    // Déterminer la version du fichier
    $version = 1;
    $baseFilename = "EME_{$codeEmetteur}_{$refPeriode}_{$frequence}_{$codeBranche}_";
    $directory = __DIR__; // Répertoire actuel
    $files = glob($directory . "/" . $baseFilename . "*.xml");

    if ($files) {
        // Extraire les numéros de version des fichiers existants et déterminer le prochain numéro de version
        $maxVersion = 0;
        foreach ($files as $file) {
            if (preg_match('/_(\d+)_XML\.XML$/', $file, $matches)) {
                $fileVersion = (int)$matches[1];
                if ($fileVersion > $maxVersion) {
                    $maxVersion = $fileVersion;
                }
            }
        }
        $version = $maxVersion + 1;
    }

    $xml_filename = "{$baseFilename}{$version}_XML.XML";
    $xml->save($xml_filename);

    // Afficher le message de succès avec un lien vers le fichier XML
    echo "<div style='font-family: Arial, sans-serif; text-align: center; margin-top: 10px; padding: 30px;'>";
    echo "<h2 style='color:  #008a50 ;'>Les informations ont été enregistrées.</h2>";
   // echo "<a href='$xml_filename'>Télécharger le fichier XML</a><br>";
    echo "</div>";
}
// Fermer la connexion
$conn->close();
?>

    
<!DOCTYPE html>
<html>
<head>
    <title>Utilisation Carte</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <fieldset>
        <legend><h2>Utilisation Carte</h2></legend>
        <label for="debutperiode">Début de période:</label><br>
        <input type="date" id="debutperiode" name="debutperiode" required><br>
        <label for="finperiode">Fin de période:</label><br>
        <input type="date" id="finperiode" name="finperiode" required><br>
        <label for="totalnbcarte">Total nombre de Cartes:</label><br>
        <input type="number" id="totalnbcarte" name="totalnbcarte" required><br>
        <label for="totalvaleurcfa">total Valeur CFA:</label><br>
        <input type="number" id="totalvaleurcfa" name="totalvaleurcfa" required><br>
    </fieldset>

    <div id="details"></div>

    <button type="button" onclick="ajouterdetailscarte()">Ajouter details d'utilisation carte</button>
   
    <input type="submit" value="Soumettre">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Connexion à la base de données
    $servername = "localhost"; // À adapter selon votre configuration
    $username = "root"; // À adapter selon votre configuration
    $password = ""; // À adapter selon votre configuration
    $dbname = "users"; // À adapter selon votre configuration

    // Création de la connexion
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérification de la connexion
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Préparation de la requête d'insertion
    $stmt = $conn->prepare("INSERT INTO utilisationcarte (debutperiode, finperiode, totalnbcarte, totalvaleurcfa, typeservice_code, description, nbcarte,valeurcfa) VALUES (?, ?, ?, ?, ?, ?, ?,?)");

    if (!$stmt) {
        die("Preparation failed: " . $conn->error);
    }

    $debutperiode = $_POST['debutperiode'];
    $finperiode = $_POST['finperiode'];
    $totalnbcarte = $_POST['totalnbcarte'];
    $totalvaleurcfa = $_POST['totalvaleurcfa'];

    echo "<div id='donneesSoumises'>";
    echo "<h2>Données soumises :</h2>";
    echo "<fieldset>";
    echo "<p>Début de période : " . htmlspecialchars($debutperiode) . "</p>";
    echo "<p>Fin de période : " . htmlspecialchars($finperiode) . "</p>";
    echo "<p>Total nombre de cartes : " . htmlspecialchars($totalnbcarte) . "</p>";
    echo "<p>total Valeur CFA : " . htmlspecialchars($totalvaleurcfa) . "</p>";

    // Création de l'objet XML
    $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><utilisationcarte/>');
    $utilisation = $xml->addChild('utilisation');
    $utilisation->addChild('debutperiode', $debutperiode);
    $utilisation->addChild('finperiode', $finperiode);
    $utilisation->addChild('totalnbcarte', $totalnbcarte);
    $utilisation->addChild('totalvaleurcfa', $totalvaleurcfa);

    $details = $xml->addChild('details');

   // $stmt->bind_param("ssiiisssssssssss", $debutperiode, $finperiode, $totalnbcarte, $totalvaleurcfa, $typeservice_code, $description, $nbcarte, $risque, $nboccurrence, $descriptiondetaillee, $mesurescorrectives, $impactfinancier, $statutincident, $datecloture, $infoscomplementaires);
   $stmt->bind_param("ssiissii", $debutperiode, $finperiode, $totalnbcarte, $totalvaleurcfa, $typeservice_code, $description, $nbcarte,$valeurcfa);
    
    $stmt->execute();

    if (!empty($_POST['typeservice_code'])) {
        echo "<h3>Details :</h3>";
        echo "<ul>";
        foreach ($_POST['typeservice_code'] as $key => $value) {
            $typeservice_code = !empty($_POST['typeservice_code'][$key]) ? $_POST['typeservice_code'][$key] : null;
            $description = !empty($_POST['description'][$key]) ? $_POST['description'][$key] : null;
            $nbcarte = !empty($_POST['nbcarte'][$key]) ? $_POST['nbcarte'][$key] : null;
            $valeurcfa = !empty($_POST['valeurcfa'][$key]) ? $_POST['valeurcfa'][$key] : null;

            echo "<li>Données utilisation carte " . ($key + 1) . "</li>";
            echo "<ul>";
            echo "<li>Code Type service : " . htmlspecialchars($typeservice_code) . "</li>";
            echo "<li>Description : " . htmlspecialchars($description) . "</li>";
            echo "<li>Nombre de cartes : " . htmlspecialchars($nbcarte) . "</li>";
            echo "<li>Valeur en CFA : " . htmlspecialchars($valeurcfa) . "</li>";

            // Ajout des détails dans le fichier XML
            $typeservice = $details->addChild('typeservice');
            $typeservice->addAttribute('code', $typeservice_code);
            $typeservice->addChild('description', $description);
            $typeservice->addChild('nbcarte', $nbcarte);
            $typeservice->addChild('valeurcfa', $valeurcfa);
            // Insertion des détails dans la base de données
            //$stmt->bind_param("ssissssssssisss", $debutperiode, $finperiode, $totalnbcarte, $totalvaleurcfa, $typeservice_code, $description, $nbcarte, $risque, $nboccurrence, $descriptiondetaillee, $mesurescorrectives, $impactfinancier, $statutincident, $datecloture, $infoscomplementaires);
            $stmt->execute();
        }
        echo "</ul>";
    }
    echo "</fieldset>";
    echo "</div>";

    // Fermeture de la requête et de la connexion
    $stmt->close();
    $conn->close();

    // Enregistrement du fichier XML
    $dom = new DOMDocument('1.0');
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    $dom->loadXML($xml->asXML());
    // Nom du fichier XML
    $xml_filename = "EME_CODEETABLISSEMENT_" . date("d_m_Y") . "_S_UTILCARTE_1_XML.xml";
    $dom->save($xml_filename);
}
?>

<script>
var numData = 1;

function ajouterdetailscarte() {
    var detailsDiv = document.getElementById("details");

    var fieldset = document.createElement("fieldset");
    var legend = document.createElement("legend");
    legend.textContent = "Details utilisation carte " + numData;
    fieldset.appendChild(legend);

    var labeltypeservice_code = document.createElement("label");
    labeltypeservice_code.setAttribute("for", "typeservice_code_" + numData);
    labeltypeservice_code.textContent = "Code Type Service:";
    fieldset.appendChild(labeltypeservice_code);
    var inputtypeservice_code = document.createElement("input");
    inputtypeservice_code.type = "text";
    inputtypeservice_code.id = "typeservice_code_" + numData;
    inputtypeservice_code.name = "typeservice_code[]";
    fieldset.appendChild(inputtypeservice_code);
    fieldset.appendChild(document.createElement("br"));

    var labeldescription = document.createElement("label");
    labeldescription.setAttribute("for", "description_" + numData);
    labeldescription.textContent = "Description:";
    fieldset.appendChild(labeldescription);
    var inputdescription = document.createElement("input");
    inputdescription.type = "text";
    inputdescription.id = "description_" + numData;
    inputdescription.name = "description[]";
    fieldset.appendChild(inputdescription);
    fieldset.appendChild(document.createElement("br"));

    var labelnbcarte = document.createElement("label");
    labelnbcarte.setAttribute("for", "nbcarte_" + numData);
    labelnbcarte.textContent = "Nombre de Cartes:";
    fieldset.appendChild(labelnbcarte);
    var inputnbcarte = document.createElement("input");
    inputnbcarte.type = "number";
    inputnbcarte.id = "nbcarte_" + numData;
    inputnbcarte.name = "nbcarte[]";
    fieldset.appendChild(inputnbcarte);
    fieldset.appendChild(document.createElement("br"));

    var labelvaleurcfa = document.createElement("label");
    labelvaleurcfa.setAttribute("for", "valeurcfa_" + numData);
    labelvaleurcfa.textContent = "Valeur en CFA:";
    fieldset.appendChild(labelvaleurcfa);
    var inputvaleurcfa = document.createElement("input");
    inputvaleurcfa.type = "number";
    inputvaleurcfa.id = "valeurcfa_" + numData;
    inputvaleurcfa.name = "valeurcfa[]";
    fieldset.appendChild(inputvaleurcfa);
    fieldset.appendChild(document.createElement("br"));

    var button = document.createElement('button');
        button.type = 'button';
        button.textContent = 'Supprimer';
        button.onclick = function() {
            detailsDiv.removeChild(fieldset);
        };

        fieldset.appendChild(button);
    

    detailsDiv.appendChild(fieldset);

    numData++;
}

</script>
</body>
</html>
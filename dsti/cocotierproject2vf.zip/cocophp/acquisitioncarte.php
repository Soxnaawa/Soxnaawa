<!DOCTYPE html>
<html>
<head>
    <title>Acquisition Carte</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <!-- Formulaire pour déclarer les acquisitions de cartes -->
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
    <legend><h2>Acquisition de Carte</h2></legend>
        <fieldset>
            <legend><h2>Acquisition</h2></legend>
            <label for="debutperiode">Date de début</label><br>
            <input type="date" id="debutperiode" name="debutperiode" required><br>
            <label for="finperiode">Date de fin</label><br>
            <input type="date" id="finperiode" name="finperiode" required><br>
        </fieldset>
        <fieldset>
            <legend><h3>Détails des Acquisitions de Cartes</h3></legend>
            <div id="details">
                <!-- Les champs pour les détails des acquisitions de cartes seront générés ici par JavaScript -->
            </div>
            <button type="button" onclick="ajouterAcquisition()">Ajouter Acquisition de Carte</button>
         
        </fieldset>
        <input type="submit" value="Soumettre">
    </form>
    <script>
    var numAcquisition = 1; // Initialisation du compteur d'Acquisition

    function ajouterAcquisition() {
        var detailsDiv = document.getElementById('details');

        var fieldset = document.createElement('fieldset');
        var legend = document.createElement('legend');
        legend.textContent = 'Acquisition De Paiement ' + numAcquisition;
        fieldset.appendChild(legend);

        // Génération automatique du code du type de carte
        var typeCarteCode = 'FCARTE_' + numAcquisition + '_T2';

        var labelTypeCarteCode = document.createElement('label');
        labelTypeCarteCode.textContent = 'Code du Type de Carte';
        var inputTypeCarteCode = document.createElement('input');
        inputTypeCarteCode.type = 'text';
        inputTypeCarteCode.name = 'typecartecode[]';
        inputTypeCarteCode.value = typeCarteCode;
        inputTypeCarteCode.readOnly = false; // Pour empêcher la modification
        inputTypeCarteCode.required = true;

        var labelTarif = document.createElement('label');
        labelTarif.textContent = 'Tarif';
        var inputTarif = document.createElement('input');
        inputTarif.type = 'number';
        inputTarif.name = 'tarif[]';
        inputTarif.required = true;

        var labelPlafondRechargement = document.createElement('label');
        labelPlafondRechargement.textContent = 'Plafond de Rechargement';
        var inputPlafondRechargement = document.createElement('input');
        inputPlafondRechargement.type = 'number';
        inputPlafondRechargement.name = 'plafondrechargement[]';
        inputPlafondRechargement.required = true;

        var labelPlafondRetraitJournalier = document.createElement('label');
        labelPlafondRetraitJournalier.textContent = 'Plafond de Retrait Journalier';
        var inputPlafondRetraitJournalier = document.createElement('input');
        inputPlafondRetraitJournalier.type = 'number';
        inputPlafondRetraitJournalier.name = 'plafondretraitjournalier[]';
        inputPlafondRetraitJournalier.required = true;

        fieldset.appendChild(labelTypeCarteCode);
        fieldset.appendChild(inputTypeCarteCode);
        fieldset.appendChild(document.createElement('br'));
        fieldset.appendChild(labelTarif);
        fieldset.appendChild(inputTarif);
        fieldset.appendChild(document.createElement('br'));
        fieldset.appendChild(labelPlafondRechargement);
        fieldset.appendChild(inputPlafondRechargement);
        fieldset.appendChild(document.createElement('br'));
        fieldset.appendChild(labelPlafondRetraitJournalier);
        fieldset.appendChild(inputPlafondRetraitJournalier);
        fieldset.appendChild(document.createElement('br'));

        // Ajouter le bouton de retour
        var button = document.createElement('button');
        button.type = 'button';
        button.textContent = 'Supprimer';
        button.onclick = function() {
            detailsDiv.removeChild(fieldset);
        };

        fieldset.appendChild(button);
        detailsDiv.appendChild(fieldset);
        numAcquisition++;
    }
</script>

    <?php
    // Paramètres de connexion à la base de données
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "users";

    // Connexion à la base de données
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Vérifier la connexion
    if ($conn->connect_error) {
        die("Échec de la connexion : " . $conn->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Récupérer les données soumises du formulaire
        $debutperiode = $_POST['debutperiode'];
        $finperiode = $_POST['finperiode'];
        $typecartecode = $_POST['typecartecode'];
        $tarif = $_POST['tarif'];
        $plafondrechargement = $_POST['plafondrechargement'];
        $plafondretraitjournalier = $_POST['plafondretraitjournalier'];

        // Afficher les données soumises
        echo "<div id='donneesSoumises'>";
        echo "<h2>Données Soumises :</h2>";
        echo "<p>Date de début : " . htmlspecialchars($debutperiode) . "</p>";
        echo "<p>Date de fin : " . htmlspecialchars($finperiode) . "</p>";
        echo "<h3>Détails des Acquisitions de Cartes</h3>";

        // Préparer la requête d'insertion
        $stmt = $conn->prepare("INSERT INTO acquisitions (debutperiode, finperiode, typecartecode, tarif, plafondrechargement, plafondretraitjournalier) VALUES (?, ?, ?, ?, ?, ?)");

        for ($i = 0; $i < count($typecartecode); $i++) {
            echo "<p>Acquisition de Carte " . ($i + 1) . " :</p>";
            echo "<p>Code du Type de Carte : " . htmlspecialchars($typecartecode[$i]) . "</p>";
            echo "<p>Tarif : " . htmlspecialchars($tarif[$i]) . "</p>";
            echo "<p>Plafond de Rechargement : " . htmlspecialchars($plafondrechargement[$i]) . "</p>";
            echo "<p>Plafond de Retrait Journalier : " . htmlspecialchars($plafondretraitjournalier[$i]) . "</p>";

            // Lier les paramètres et exécuter la requête
            $stmt->bind_param("sssddd", $debutperiode, $finperiode, $typecartecode[$i], $tarif[$i], $plafondrechargement[$i], $plafondretraitjournalier[$i]);
            $stmt->execute();
        }

        echo "</div>";

        // Fermer la requête préparée
        $stmt->close();

        // Générer le fichier XML
        $xml = new DOMDocument('1.0', 'UTF-8');
        $xml->formatOutput = true;

        // Élément racine <acquisitioncarte>
        $acquisitioncarte = $xml->createElement('acquisitioncarte');
        $xml->appendChild($acquisitioncarte);

        // Élément <acquisition>
        $acquisition = $xml->createElement('acquisition');
        $acquisitioncarte->appendChild($acquisition);

        $acquisition->appendChild($xml->createElement('debutperiode', $debutperiode));
        $acquisition->appendChild($xml->createElement('finperiode', $finperiode));

        // Élément <details>
        $detailsElem = $xml->createElement('details');
        $acquisitioncarte->appendChild($detailsElem);

        // Itérer sur les acquisitions de cartes
        for ($i = 0; $i < count($typecartecode); $i++) {
            $typeCarteElem = $xml->createElement('typecarte');
            $typeCarteElem->setAttribute('code', htmlspecialchars($typecartecode[$i]));

            $typeCarteElem->appendChild($xml->createElement('tarif', $tarif[$i]));
            $typeCarteElem->appendChild($xml->createElement('plafondrechargement', $plafondrechargement[$i]));
            $typeCarteElem->appendChild($xml->createElement('plafondretraitjournalier', $plafondretraitjournalier[$i]));

            $detailsElem->appendChild($typeCarteElem);
        }

        // Construire le nom de fichier selon la nomenclature
        $codeEmetteur = "CODEETABLISSEMENT"; // Remplacez par la valeur appropriée
        $refPeriode = date("d_m_Y");
        $frequence = "S"; // Exemple, remplacez par la valeur appropriée
        $codeBranche = "ACQUICARTE"; // Remplacez par la valeur appropriée

        // Déterminer la version du fichier
        $version = 1;
        $baseFilename = "EME_{$codeEmetteur}_{$refPeriode}_{$frequence}_{$codeBranche}_";
        $directory = __DIR__; // Répertoire actuel
        $files = glob($directory . "/" . $baseFilename . "*.xml");

        if ($files) {
            // Extraire les numéros de version des fichiers existants et déterminer le prochain numéro de version
            $maxVersion = 0;
            foreach ($files as $file) {
                if (preg_match('/_(\d+)_XML\.XML$/', $file, $matches)) {
                    $fileVersion = (int)$matches[1];
                    if ($fileVersion > $maxVersion) {
                        $maxVersion = $fileVersion;
                    }
                }
            }
            $version = $maxVersion + 1;
        }

        $xml_filename = "{$baseFilename}{$version}_XML.XML";
        $xml->save($xml_filename);

        // Afficher le message de succès avec un lien vers le fichier XML
        echo "<div style='font-family: Arial, sans-serif; text-align: center; margin-top: 10px; padding: 30px;'>";
        echo "<h2 style='color: #008a50;'>Les informations ont été enregistrées.</h2>";
        echo "<a href='$xml_filename'>Télécharger le fichier XML</a><br>";
        echo "</div>";
    }

    // Fermer la connexion
    $conn->close();
    ?>
</body>
</html>
